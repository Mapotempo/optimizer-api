# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fastvrpy', 'fastvrpy.core']

package_data = \
{'': ['*'],
 'fastvrpy.core': ['moves/generator.pxi',
                   'moves/generator.pxi',
                   'moves/generator.pxi',
                   'moves/generator.pxi',
                   'moves/generator.pxi',
                   'moves/generator.pxi',
                   'moves/generator.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_relocate.pxi',
                   'moves/inter_swap.pxi',
                   'moves/inter_swap.pxi',
                   'moves/inter_swap.pxi',
                   'moves/inter_swap.pxi',
                   'moves/inter_swap.pxi',
                   'moves/inter_swap.pxi',
                   'moves/inter_swap.pxi',
                   'moves/opt2.pxi',
                   'moves/opt2.pxi',
                   'moves/opt2.pxi',
                   'moves/opt2.pxi',
                   'moves/opt2.pxi',
                   'moves/opt2.pxi',
                   'moves/opt2.pxi',
                   'moves/relocate.pxi',
                   'moves/relocate.pxi',
                   'moves/relocate.pxi',
                   'moves/relocate.pxi',
                   'moves/relocate.pxi',
                   'moves/relocate.pxi',
                   'moves/relocate.pxi',
                   'moves/swap.pxi',
                   'moves/swap.pxi',
                   'moves/swap.pxi',
                   'moves/swap.pxi',
                   'moves/swap.pxi',
                   'moves/swap.pxi',
                   'moves/swap.pxi',
                   'moves/vector_relocate.pxi',
                   'moves/vector_relocate.pxi',
                   'moves/vector_relocate.pxi',
                   'moves/vector_relocate.pxi',
                   'moves/vector_relocate.pxi',
                   'moves/vector_relocate.pxi',
                   'moves/vector_relocate.pxi']}

install_requires = \
['Cython>=0.29.32,<0.30.0',
 'matplotlib>=3.6.2,<4.0.0',
 'numpy>=1.23.4,<2.0.0',
 'plotly>=5.11.0,<6.0.0',
 'psutil>=5.9.4,<6.0.0',
 'scikit-learn>=1.1.3,<2.0.0',
 'scipy>=1.9.3,<2.0.0']

setup_kwargs = {
    'name': 'fastvrpy',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Guillaume Maran',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
