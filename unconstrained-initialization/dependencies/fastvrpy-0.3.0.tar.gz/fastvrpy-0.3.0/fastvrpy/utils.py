import numpy
import itertools
from sklearn.cluster import KMeans, AgglomerativeClustering, OPTICS, SpectralClustering, MiniBatchKMeans, DBSCAN
from fastvrpy.core import algorithm
from fastvrpy.core.solutions import cvrptw


import os
import logging as log

from statistics import mean

from sklearn.neighbors import NearestCentroid

from scipy.stats import truncnorm

import math

def max_quantities(capacity, quantities):
    if capacity > -1:
        n = len(quantities)
        dp = [[0] * (capacity+1) for _ in range(n+1)]
        for i in range(1, n+1):
            for j in range(1, capacity+1):
                dp[i][j] = dp[i-1][j]
                if quantities[i-1] <= j:
                    dp[i][j] = max(dp[i][j], dp[i-1][j-int(quantities[i-1])] + 1)
        return dp[n][capacity]
    else :
        return len(quantities)-1

def max_group_size(vehicle_capacities, services_volumes, num_units):
    max_group_sizes = []
    for unit in range(num_units):
        quantities = []
        capacities = []
        for quantity in (services_volumes):
            quantities.append(quantity[unit])
        for capacity in vehicle_capacities:
            capacities.append(capacity[unit])
        capacity = int(min(capacities))
        max_group_sizes.append(max_quantities(capacity, quantities))
    return min(max_group_sizes)

def log_config():
    """Setup the logger

    The logger will write its output in a new file every day at midnight

    Returns
    -------
    log : logging.getLogger
        Configurated logger to use in all the package

    """

    # Constants
    PATH_TO_LOG = os.path.join(
        os.getcwd(), "init_vrp.log"
    )
    LOG_FORMAT = "%(asctime)s | %(levelname)s\t | %(name)s\t : %(message)s"
    LOGGING_MODE = log.DEBUG

    #(PATH_TO_LOG, when="midnight", interval=1, encoding="utf8")
    log.basicConfig(filename=PATH_TO_LOG, format=LOG_FORMAT, level=LOGGING_MODE)

    # Set numba logging to warning only
    vrp_logger = log.getLogger("fast-vrp-init")
    vrp_logger.setLevel(LOGGING_MODE)

    # Set numba logging to warning only
    root_logger = log.getLogger("root")
    root_logger.setLevel(LOGGING_MODE)


def get_mixture_truncated_normal(num_values = 10, weights = [0.5, 0.5], means=[0,0], sigmas=[1,1], low=0, upp=10):

    models = [truncnorm(low - mean/sigma, (upp - mean) / sigma, loc=mean, scale=sigma) for mean, sigma in zip(means, sigmas)]
    sizes = [int(weight * num_values) for weight in weights]
     # Normalize the weights
    normalized_weights = [weight / sum(weights) for weight in weights]

    # Calculate each subvalue
    sizes = [int(weight * num_values) for weight in normalized_weights]

    # Check if the sum of sizes is equal to size
    if sum(sizes) != num_values:
        # Add or subtract 1 from one of the elements of sizes to correct this
        sizes[-1] += num_values - sum(sizes)

    values = numpy.concatenate([model.rvs(size) for model, size in zip(models, sizes)], dtype=float)

    return values

def bundled_matrix(solution, groups):
    matrix = solution.time_matrix[0]
    bundled_matrix = []
    for group_index_from in range(len(groups)):
        bundled_matrix_row = []
        service_from = groups[group_index_from][0]
        service_from_matrix_index = solution.service_matrix_index[service_from]
        for group_index_to in range(len(groups)):
            service_to = groups[group_index_to][0]
            service_to_matrix_index = solution.service_matrix_index[service_to]
            bundled_matrix_row.append(matrix[service_from_matrix_index, service_to_matrix_index])
        bundled_matrix.append(bundled_matrix_row)
    return numpy.array(bundled_matrix)

def process_initial_solution(num_vehicle, matrix, store_indexes, sticky = {}):

    log.info("Process Initial Solution")
    log.debug("-- Clustering")
    cluster = AgglomerativeClustering(n_clusters=min(num_vehicle, matrix.shape[0]), metric='precomputed', linkage='complete').fit(matrix)
    #cluster = MiniBatchKMeans(n_clusters=min(num_vehicle, matrix.shape[0])).fit(matrix)

    # print(cluster.labels_)
    # numpy.random.shuffle(cluster.labels_)
    # print(cluster.labels_)

    log.debug("-- Compute initial solution")

    num_services = numpy.zeros(num_vehicle, dtype=int)
    for i in range(0, cluster.labels_.size ):
        vehicle = cluster.labels_[i]
        num_services[vehicle] += 1

    max_capacity = matrix.shape[0]
    num_services = numpy.zeros(num_vehicle, dtype=int)

    initial_paths = numpy.full((num_vehicle, max_capacity), -1, dtype=numpy.int32)

    for service in range(0, cluster.labels_.size ):
        if service in sticky.keys() and sticky[service].size > 0:
            vehicle = sticky[service][0]
        else:
            vehicle = cluster.labels_[service]
        position = num_services[vehicle]
        initial_paths[vehicle, position] = service
        num_services[vehicle] += 1

    return initial_paths


def generate_point(radius_max, center):
    """
    Function that generates random point (coordinate latitude, longitude) on earth around a center point
    """
    #First generate the points

    # angle for this random point
    angle = numpy.float64(2 * numpy.pi * numpy.random.random_sample())
    # radius from fence center
    radius = radius_max * numpy.sqrt(numpy.float64(numpy.random.uniform(0, 1)))

    # diff from ceneter in radians
    latitudinal_diff_rad = radius * numpy.sin(angle) / numpy.float64(6371)
    longitudinal_diff_rad = radius * numpy.cos(angle) / numpy.float64(6371)

    # radians to degrees
    latitudinal_diff = latitudinal_diff_rad * 180 / numpy.pi
    longitudinal_diff = longitudinal_diff_rad * 180 / numpy.pi


    return (numpy.float64(center[0]) + latitudinal_diff, numpy.float64(center[1]) + longitudinal_diff)


def solution_unbundle(solution, groups):

    log.info("Process Solution Unbundling")

    new_paths = [[] for _ in range(solution.num_vehicles)]
    max_len = 0

    for i in range(solution.num_vehicles):
        for j in range(solution.vehicle_num_services[i]):
            services = groups[solution.paths[i,j]]
            new_paths[i] += services
        if len(new_paths[i]) > max_len:
            max_len = len(new_paths[i])

    paths = numpy.full((solution.num_vehicles, max_len + 10), -1, dtype=numpy.int32)
    for i in range(solution.num_vehicles):
        for j in range(len(new_paths[i])):
            paths[i,j] = new_paths[i][j]

    return paths


def solution_bundle(solution, max_group_size):

    log.info("Process Solution Grouping")

    matrix = solution.time_matrix[0]

    groups = []

    for start in range(matrix.shape[0]):
        start_group = next((group for group in groups if start in group), None)
        #Check if start is already in a group, if not add it
        if start_group is None:
            #create a new group with the
            groups.append([start])
            # save the index of the start group
            start_group = groups[-1]


        for destination in range(start + 1, matrix.shape[0]):
            destination_group = next((group for group in groups if destination in group), None)

            if destination_group is None:
                if matrix[start, destination] == 0:
                    #It is the same point add destination to the group
                    #If the group size is is OK
                    if len(start_group) < max_group_size:
                        start_group.append(destination)
                    else:
                        #Create a new group for destinaiton
                        groups.append([destination])
                        start_group = groups[-1]

    return groups


def solution_grouping(solution, max_group_size, problem):
    log.info("Process Solution Grouping")
    services = problem['services']
    max_service_index = max([service["matrixIndex"] for service in services])
    groups = [[] for _ in range(max_service_index+1)]
    for index, service in enumerate(services):
        groups[service["matrixIndex"]].append(index)
    final_groups = []
    for group in groups:
        if len(group) == 0:
            continue
        if len(group) <= max_group_size:
            final_groups.append(group)
        else:
            nb = math.ceil(len(group) / max_group_size)
            reste = len(group) % max_group_size if len(
                group) % max_group_size > 0 else max_group_size
            for i in range(nb-1):
                new_group = group[i*max_group_size:(i+1)*max_group_size]
                final_groups.append(new_group)
            new_group = group[(i+1)*max_group_size:(i+1)*max_group_size+reste]
            final_groups.append(new_group)
    return final_groups


def print_kpis(solution):
    early = 0
    lates = 0
    cumul = 0
    max_late = 0
    overloads = [0 for i in range(solution.num_units)]
    vehicle_late = 0
    vehicle_late_time = 0
    vehicle_over_distance = 0
    total_travel_distance = 0
    total_travel_time = 0

    for vehicle in range(solution.num_vehicles):
        total_travel_distance += solution.distances[vehicle]
        total_travel_time += solution.travel_times[vehicle]
        if solution.vehicle_max_distance[vehicle] > -1 and solution.distances[vehicle] > solution.vehicle_max_distance[vehicle] :
            vehicle_over_distance += 1
        for unit_index in range(solution.num_units):
            if solution.vehicle_capacities[vehicle,unit_index] > -1 and solution.vehicle_occupancies[vehicle, unit_index] > solution.vehicle_capacities[vehicle, unit_index]:
                overloads[unit_index] += 1
        if solution.vehicle_end_time_window[vehicle] > -1 and solution.vehicle_ends[vehicle] > solution.vehicle_end_time_window[vehicle]:
            vehicle_late += 1
            vehicle_late_time += solution.vehicle_ends[vehicle] - solution.vehicle_end_time_window[vehicle]

        for point in range(solution.vehicle_num_services[vehicle]):
            start = solution.starts[vehicle][point+1]
            service = solution.paths[vehicle][point]


            s_tw = solution.start_time_windows[service,0]
            e_tw = solution.max_end_time_windows[service]

            if start < s_tw :
                early += 1
                cumul +=  s_tw - start
            elif e_tw > -1 and start > e_tw:
                #print(start, s_tw, e_tw, vehicle, point)
                lates += 1
                cumul += start - e_tw
                if start - e_tw > max_late:
                    max_late = start - e_tw

    vehicle_mean_late = vehicle_late_time/60/vehicle_late if vehicle_late > 0 else 0

    log.info(f"Print KPIs")
    log.info(f"SOLUTION COST {solution.total_cost}" )
    log.info(f"Travel distance : {total_travel_distance/1000} kilometers" )
    log.info(f"Travel time : {total_travel_time/3600} hours" )
    log.debug(f"Partial costs \n {numpy.array(solution.costs)}")
    log.debug(f"Number services \n {numpy.array(solution.vehicle_num_services)}")
    log.info(f"Vehicle distance violations {vehicle_over_distance}")
    log.info(f"Vehicle overloads {overloads}")
    log.info(f"{vehicle_late} vehicles with working hours overflow (mean {vehicle_mean_late} minutes)" )
    log.info(f"Too early (MUST be 0 by construction) {early}")
    log.info(f"Too lates {lates}" )
    log.info(f"Total late {cumul}")
    log.info(f"Worse late {max_late/60}")




def calculate_cluster_distance_matrix(clusters, distance_matrix):
    """
    Calculate the average distance between each pair of clusters using the global distance matrix.

    Parameters
    ----------
    clusters : list of list of int
        A list of clusters, where each cluster is represented by a list of points.
    distance_matrix : numpy.ndarray
        A 2D numpy array containing the distance between each pair of points.

    Returns
    -------
    numpy.ndarray
        A 2D numpy array containing the average distance between each pair of clusters.
    """
    # Create an empty matrix to store the distances between the clusters
    cluster_distance_matrix = numpy.zeros((len(clusters), len(clusters)))

    # Loop over all pairs of clusters
    for i in range(len(clusters)):
        for j in range(len(clusters)):
            # Calculate the average distance between the points in cluster i and the points in cluster j
            distance_sum = 0
            for point_i in clusters[i]:
                for point_j in clusters[j]:
                    distance_sum += distance_matrix[point_i][point_j]
            distance_mean = distance_sum / (len(clusters[i]) * len(clusters[j]))

            # Save the average distance in the cluster distance matrix
            cluster_distance_matrix[i][j] = distance_mean

    return cluster_distance_matrix


def cluster_bundle(solution, groups):

    log.info("Process Cluster Bundling")

    num_depots = numpy.unique(numpy.concatenate((solution.vehicle_start_index,solution.vehicle_end_index))).shape[0]
    #rebuild the distance matrix from this grouping
    new_size            = len(groups)
    num_matrix          = solution.time_matrix.shape[0]
    new_start_tw        = numpy.zeros((new_size,1), dtype=numpy.float64)
    new_end_tw          = numpy.zeros((new_size,1), dtype=numpy.float64)
    new_durations       = numpy.zeros(new_size, dtype=numpy.float64)
    new_setup_durations = numpy.zeros(new_size, dtype=numpy.float64)
    new_services_volume = numpy.zeros((new_size,solution.num_units), dtype=numpy.float64)
    new_services_matrix_index = numpy.zeros(new_size, dtype=numpy.int32)


    #For vehicles... Just make a copy
    new_cost_distance_multiplier    = numpy.copy(solution.cost_distance_multiplier)
    new_cost_time_multiplier        = numpy.copy(solution.cost_time_multiplier)
    new_vehicle_capacity            = numpy.copy(solution.vehicle_capacities)
    new_previous_vehicle            = numpy.copy(solution.previous_vehicle)
    new_vehicle_start_time_window   = numpy.copy(solution.vehicle_start_time_window)
    new_vehicle_end_time_window     = numpy.copy(solution.vehicle_end_time_window)
    new_vehicle_max_distance        = numpy.copy(solution.vehicle_max_distance)
    new_vehicle_fixed_costs         = numpy.copy(solution.vehicle_fixed_costs)
    new_vehicle_overload_multiplier = numpy.copy(solution.vehicle_overload_multiplier)
    new_vehicle_matrix_index        = numpy.copy(solution.vehicle_matrix_index)


    #Manage the predecessors
    new_predecessor_successor_gap = numpy.zeros((solution.predecessor_successor_gap.shape[0],4), dtype= numpy.int32)
    for i, constraint in enumerate(solution.predecessor_successor_gap):
        #For each constraint find the group of predecessor and successor
        predecessor = constraint[0]
        successor = constraint[1]
        new_pred = -1
        new_successor = -1
        for index, group in enumerate(groups):
            if predecessor in group:
                new_pred = index
            if successor in group:
                new_successor = index
            if new_pred != -1 and new_successor != -1:
                break
        #Add the constraint
        new_predecessor_successor_gap[i,0] = new_pred
        new_predecessor_successor_gap[i,1] = new_successor
        new_predecessor_successor_gap[i,2] = constraint[2]
        new_predecessor_successor_gap[i,3] = constraint[3]


    store_indices = []
    for store in list(set(solution.vehicle_start_index)):
        store_indices.append([store])

    num_tw = solution.start_time_windows.shape[1]
    for point in range(new_size):
        #For the start tw get the min time_window value in this cluster
        new_start_tw[point,0] = min(solution.start_time_windows[service, tw] for service in groups[point] for tw in range(num_tw))

        #For the end tw get the max end time_window value in this cluster
        new_end_tw[point,0] = max(solution.end_time_windows[service, tw ] for service in groups[point] for tw in range(num_tw))


        #For the setup duration get the sum of all points with different adresses
        unique_services_setup_durations = []
        unique_services_setup_durations = [solution.setup_durations[service] for service in groups[point] if all(solution.distance_matrix[0, service, selected_service] != 0 for selected_service in unique_services_setup_durations)]

        #Manage the setup duration
        unique_services = []
        for service in groups[point] :
            for unique_service in unique_services:
                if solution.distance_matrix[0, solution.service_matrix_index[service], solution.service_matrix_index[unique_service]] == 0:
                    #Means that the adress already exists
                    break
            else: #It's a new adress
                unique_services.append(service)
        unique_services_setup_durations = [solution.setup_durations[service] for service in unique_services]
        new_setup_durations[point] = sum(unique_services_setup_durations)

        #For the duration and the volume get the sum of all points in the group
        new_durations[point] = sum((solution.durations[service] for service in groups[point]))
        for unit_index in range(solution.num_units) :
            new_services_volume[point, unit_index] = sum((solution.services_volumes[service,unit_index] for service in groups[point]))

    new_paths = process_initial_solution(solution.num_vehicles, bundled_matrix(solution,groups), list(set(solution.vehicle_start_index)), solution.sticky_vehicles_dict)
    log.debug(f"Reduced solution paths :\n{numpy.array(new_paths)}")

    # for store_index in range(num_depots):
    #         new_start_tw[store_index + new_size] = [0 for _ in range(num_tw)]
    #         new_end_tw[store_index + new_size] = [-1 for _ in range(num_tw)]
    #         new_durations[store_index + new_size] = 0
    #         new_setup_durations[store_index + new_size] = 0
    #         new_services_volume[store_index + new_size] = [0 for _ in range(solution.num_units)]
    #         new_services_matrix_index[store_index + new_size] = -1

    #Create the new solution and return it !
    new_solution = cvrptw.CVRPTW(
        paths                       = new_paths,
        distance_matrix             = solution.distance_matrix,
        time_matrix                 = solution.time_matrix,
        start_time_windows          = new_start_tw,
        end_time_windows            = new_end_tw,
        durations                   = new_durations,
        setup_durations             = new_setup_durations,
        services_volumes            = new_services_volume,
        service_matrix_index        = new_services_matrix_index,
        cost_distance_multiplier    = new_cost_distance_multiplier,
        cost_time_multiplier        = new_cost_time_multiplier,
        vehicle_capacities          = new_vehicle_capacity,
        previous_vehicle            = new_previous_vehicle,
        vehicle_max_distance        = new_vehicle_max_distance,
        vehicle_fixed_costs         = new_vehicle_fixed_costs,
        vehicle_overload_multiplier = new_vehicle_overload_multiplier,
        vehicle_start_time_window   = new_vehicle_start_time_window,
        vehicle_end_time_window     = new_vehicle_end_time_window,
        vehicle_matrix_index        = new_vehicle_matrix_index,
        vehicle_start_index         = solution.vehicle_start_index,
        vehicle_end_index           = solution.vehicle_end_index,
        force_start                 = solution.force_start,
        free_approach               = solution.free_approach,
        free_return                 = solution.free_return,
        unassigned_services = None,
        predecessor_successor_gap = None,
        is_break = None,
        sticky_vehicles = {},
        num_units                   = solution.num_units,
        )

    return new_solution
