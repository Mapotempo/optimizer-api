import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3,4,5]], dtype=np.int32)

distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)

def test_no_waiting():

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )

    assert np.array_equal(np.array([0.]), np.array(solution.vehicle_max_waiting_time))


def test_waiting_times_with_avance():

    start_tw = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([7.]), np.array(solution.vehicle_max_waiting_time))


def test_waiting_times_with_avance_and_durations():

    start_tw = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)
    durations = np.array([0,1,1,1,1,1], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        durations = durations
        )

    assert np.array_equal(np.array([6.]), np.array(solution.vehicle_max_waiting_time))

def test_starts_with_avance_multitw():

    start_tw = np.array([[0, -1],[1, -1],[1, -1],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([1.]), np.array(solution.vehicle_max_waiting_time))

def test_max_waiting_times_multitw_two_vehicles():

    start_tw = np.array([[0, -1],[1, -1],[1, -1],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)

    paths = np.array([[1,2,3,-1,-1], [4,5,-1,-1,-1]], dtype=np.int32)
    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([1.,0.]), np.array(solution.vehicle_max_waiting_time))


def test_starts_with_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )
    assert np.array_equal(np.array([0.]), np.array(solution.vehicle_max_waiting_time))


def test_waiting_with_avance_multitw_and_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[100, 125],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[110, 130],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )


    assert np.array_equal(np.array([14.]), np.array(solution.vehicle_max_waiting_time))


def test_waiting_with_avance_multitw_and_vehicle_tw_two_vehicles():

    paths = np.array([[1,2,-1,-1,-1],[3,4,5,-1,-1]], dtype=np.int32)
    vehicle_start_time_window = np.array([100,100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[10, 125],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[11, 130],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )

    assert np.array_equal(np.array([7.,15.]), np.array(solution.vehicle_max_waiting_time))


def test_waiting_with_avance_multitw_and_vehicle_tw_two_vehicles_store_indicies_at_the_end():

    paths = np.array([[0,1,-1,-1,-1],[2,3,4,-1,-1]], dtype=np.int32)
    vehicle_start_time_window = np.array([100,100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[10, 125],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[11, 130],[-1, -1]], dtype=float)

    vehicle_start_index = np.array([5,5], dtype=np.int32)
    vehicle_end_index = np.array([5,5], dtype=np.int32)

    solution = CVRPTW(
        paths                       = paths,
        distance_matrix             = distance_matrix,
        time_matrix                 = time_matrix,
        start_time_windows          = start_tw,
        end_time_windows            = end_tw,
        vehicle_start_time_window   = vehicle_start_time_window,
        vehicle_start_index         = vehicle_start_index,
        vehicle_end_index           = vehicle_end_index,
        num_units                   = 0,
        )

    assert np.array_equal(np.array([0.,14.]), np.array(solution.vehicle_max_waiting_time))


def test_waiting_times_with_avance_multitw_and_two_vehicles_with_tw_and_store_indicies_at_the_end():

    paths = np.array([[0,1,-1,-1,-1],[2,3,4,-1,-1]], dtype=np.int32)
    vehicle_start_time_window = np.array([100,100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[10, 125],[-1, -1]], dtype=float)
    end_tw   = np.array([[-1, -1],[-1, -1],[-1, -1],[11, 130],[-1, -1]], dtype=float)

    vehicle_start_index = np.array([5,5], dtype=np.int32)
    vehicle_end_index = np.array([5,5], dtype=np.int32)

    solution = CVRPTW(
        paths                       = paths,
        distance_matrix             = distance_matrix,
        time_matrix                 = time_matrix,
        start_time_windows          = start_tw,
        end_time_windows            = end_tw,
        vehicle_start_time_window   = vehicle_start_time_window,
        vehicle_start_index         = vehicle_start_index,
        vehicle_end_index           = vehicle_end_index,
        num_units                   = 0,
        )

    assert np.array_equal(np.array([0.,14.]), np.array(solution.vehicle_max_waiting_time))

def test_waiting_with_avance_multitw_durations_and_two_vehicles_with_tw_and_store_indicies_at_the_end():

    paths = np.array([[0,1,-1,-1,-1],[2,3,4,-1,-1]], dtype=np.int32)
    vehicle_start_time_window = np.array([100,100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[10, 125],[-1, -1]], dtype=float)
    end_tw   = np.array([[-1, -1],[-1, -1],[-1, -1],[11, 130],[-1, -1]], dtype=float)
    durations = np.array([0,1,1,1,1], dtype=float)

    vehicle_start_index = np.array([5,5], dtype=np.int32)
    vehicle_end_index = np.array([5,5], dtype=np.int32)

    solution = CVRPTW(
        paths                       = paths,
        distance_matrix             = distance_matrix,
        time_matrix                 = time_matrix,
        start_time_windows          = start_tw,
        end_time_windows            = end_tw,
        vehicle_start_time_window   = vehicle_start_time_window,
        vehicle_start_index         = vehicle_start_index,
        vehicle_end_index           = vehicle_end_index,
        num_units                   = 0,
        durations                   = durations
        )

    assert np.array_equal(np.array([0.,13.]), np.array(solution.vehicle_max_waiting_time))
