import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                             [1,0,1,1,1,1],
                             [1,1,0,1,1,1],
                             [1,1,1,0,1,1],
                             [1,1,1,1,0,1],
                             [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                         [1,0,2,4,6,8],
                         [5,2,0,1,2,3],
                         [10,4,1,0,10,20],
                         [15,6,2,10,0,5],
                         [20,8,3,20,5,0],]], dtype=np.float64)

def test_unassigned_cost():
    unassigned = [4,5]
    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )
    solution.unassigned_services = np.array(unassigned, dtype=np.int32)
    solution.init_calculated_attributes()
    solution.evaluate(np.array([0], dtype=np.int32),False)
