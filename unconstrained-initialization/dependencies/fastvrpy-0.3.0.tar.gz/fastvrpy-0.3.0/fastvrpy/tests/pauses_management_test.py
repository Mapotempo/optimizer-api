import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW


distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)





def test_pauses_management_basic():
    paths = np.array([[1,2,3,4,5]], dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        durations = np.array([60,60,3600,60,60,60], dtype=np.float64),
        is_break = np.array([0,0,1,0,0,0], dtype=np.int32),
        )

    assert np.array_equal(np.array([[0,1,61,3665,3735,3800,0]]), np.array(solution.starts))


def test_pauses_management_pause_first():
    paths = np.array([[2,3,4,5,1]], dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        durations = np.array([60,60,3600,60,60,60], dtype=np.float64),
        is_break = np.array([0,0,1,0,0,0], dtype=np.int32),
        )
    assert np.array_equal(np.array([[0,0,3610,3680,3745,3813,0]]), np.array(solution.starts))

def test_pauses_management_pause_last():
    paths = np.array([[1,2,3,4,5]], dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        durations = np.array([60,60,60,60,60,3600], dtype=np.float64),
        is_break = np.array([0,0,0,0,0,1], dtype=np.int32),
        )

    assert np.array_equal(np.array([[0,1,63,124,194,254,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([3869]),np.array(solution.vehicle_ends))

def test_pauses_management_2_consecutive():
    """
    When consecutive pause, we should count the 2 pauses sequentialy but without changing the last normal start place
    """
    paths = np.array([[1,2,3,4,5]], dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        durations = np.array([60,60,3600,400,60,60], dtype=np.float64),
        is_break = np.array([0,0,1,1,0,0], dtype=np.int32),
        )

    assert np.array_equal(np.array([[0,1,61,3661,4067,4132,0]]), np.array(solution.starts))
