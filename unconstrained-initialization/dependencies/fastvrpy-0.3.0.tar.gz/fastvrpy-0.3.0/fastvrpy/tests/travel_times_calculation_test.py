import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW


paths = np.array([[1,2,3,4,5]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)


def test_travel_times():

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    time_matrix    = np.array([[[0,1,1,1,1,1],
                                [1,0,1,1,1,1],
                                [1,1,0,1,1,1],
                                [1,1,1,0,1,1],
                                [1,1,1,1,0,1],
                                [1,1,1,1,1,0],]], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )

    assert np.array_equal(np.array([6]), solution.travel_times)

def test_travel_times2():

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    time_matrix    = np.array([[[0,2,1,1,1,1],
                                [1,0,3,1,1,1],
                                [1,1,0,4,1,1],
                                [1,1,1,0,5,1],
                                [1,1,1,1,0,1],
                                [1,1,1,1,1,0],]], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )
    assert np.array_equal(np.array([16]), np.array(solution.travel_times))

def test_travel_times_with_index_of_store_at_the_end():

    paths = np.array([[0,1,2,3,4]], dtype=np.int32)
    time_matrix    = np.array([[[0,2,1,1,1,1],
                                [1,0,3,1,1,1],
                                [1,1,0,4,1,1],
                                [1,1,1,0,5,1],
                                [1,1,1,1,0,1],
                                [7,1,1,1,1,0],]], dtype=np.float64)
    vehicle_start_index = np.array([5], dtype=np.int32)
    vehicle_end_index   = np.array([5], dtype=np.int32)

    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        num_units           = 0,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index   = vehicle_end_index
        )
    assert np.array_equal(np.array([22]), np.array(solution.travel_times))

def test_travel_times_with_differents_store_indicies():

    paths = np.array([[1,2,3,4]], dtype=np.int32)
    time_matrix    = np.array([[[0,2,2,2,2,2],
                                [1,0,3,1,1,1],
                                [1,1,0,4,1,1],
                                [1,1,1,0,5,1],
                                [1,1,1,1,0,8],
                                [1,1,1,1,1,0],]], dtype=np.float64)

    vehicle_start_index = np.array([0], dtype=np.int32)
    vehicle_end_index   = np.array([5], dtype=np.int32)

    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        num_units           = 0,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index   = vehicle_end_index
        )
    assert np.array_equal(np.array([22]), np.array(solution.travel_times))
