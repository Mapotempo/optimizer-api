import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3,4,5]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)

def test_starts():

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,3,4,14,19,0]]), solution.starts)
    assert np.array_equal(np.array([0]), np.array(solution.vehicle_starts))

def test_force_start():

    force_start = np.array([1], dtype=np.int32 )

    start_tw = np.array([[100],[101],[110],[-1],[-1],[-1]], dtype=float)
    vehicle_start_time_window = np.array([4], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        force_start = force_start,
        start_time_windows = start_tw,
        vehicle_start_time_window = vehicle_start_time_window
        )
    assert np.array_equal(np.array([[100, 101, 110, 111, 121, 126, 0]]), np.array(solution.starts))
    assert np.array_equal(np.array([4]), np.array(solution.vehicle_starts))

def test_starts_with_avance():

    start_tw = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        vehicle_start_time_window = vehicle_start_time_window
        )

    assert np.array_equal(np.array([[100, 101, 103, 104, 114, 119, 0]]), np.array(solution.starts))
    assert np.array_equal(np.array([100]), np.array(solution.vehicle_starts))

def test_starts_with_multi_tour():

    paths            = np.array([[1,2,3,-1,-1],[4,5,-1,-1,-1]], dtype=np.int32)

    start_tw         = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)
    previous_vehicle = np.array([-1, 0], dtype=np.int32)

    vehicle_start_time_window = np.array([100,100], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        vehicle_start_time_window = vehicle_start_time_window,
        previous_vehicle = previous_vehicle
        )
    assert np.array_equal(np.array([100,114]), np.array(solution.vehicle_starts))

def test_starts_with_no_multi_tour():

    paths            = np.array([[1,2,3,-1,-1],[4,5,-1,-1,-1]], dtype=np.int32)
    start_tw         = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)
    previous_vehicle = np.array([-1, -1], dtype=np.int32)

    vehicle_start_time_window = np.array([100,100], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        vehicle_start_time_window = vehicle_start_time_window,
        previous_vehicle = previous_vehicle
        )
    assert np.array_equal(np.array([100,100]), np.array(solution.vehicle_starts))


def test_starts_with_no_multi_tour_and_avance():

    paths            = np.array([[1,2,3,-1,-1],[4,5,-1,-1,-1]], dtype=np.int32)
    start_tw         = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)
    previous_vehicle = np.array([-1, -1], dtype=np.int32)

    vehicle_start_time_window = np.array([100,130], dtype=np.float64)

    solution = CVRPTW(
            paths = paths,
            distance_matrix = distance_matrix,
            time_matrix = time_matrix,
            start_time_windows = start_tw,
            num_units = 0,
            vehicle_start_time_window = vehicle_start_time_window,
            previous_vehicle = previous_vehicle
        )

    assert np.array_equal(np.array([100,130]), np.array(solution.vehicle_starts))

def test_starts_with_multi_tour_first_tour_is_empty():

    paths            = np.array([[-1,-1,-1,-1,-1],[4,5,3,2,1]], dtype=np.int32)
    start_tw         = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)
    previous_vehicle = np.array([-1, 0], dtype=np.int32)

    vehicle_start_time_window = np.array([100,130], dtype=np.float64)

    solution = CVRPTW(
            paths = paths,
            distance_matrix = distance_matrix,
            time_matrix = time_matrix,
            start_time_windows = start_tw,
            num_units = 0,
            vehicle_start_time_window = vehicle_start_time_window,
            previous_vehicle = previous_vehicle
        )

    assert np.array_equal(np.array([0,130]), np.array(solution.vehicle_starts))
