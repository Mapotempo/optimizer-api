import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3,4,5]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)





def test_costs_no_costs():

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )

    assert np.array_equal(np.array([0]), np.array(solution.costs))



@pytest.fixture(params=[
    [[-1,-1,-1,-1,-1]],
    [[1,2,3,4,5]],
    [[1,2,3,-1,-1], [4,5,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,-1,-1,-1], [3,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,3,-1,-1], [-1,-1,-1,-1,-1]],
    ])
def path_fixture(request):
    return request.param

@pytest.fixture(params=[0.001, 0.2, 0.5, 1, 10])
def cost_fixture(request):
    return request.param


def test_costs_no_constraint(path_fixture, cost_fixture):

    paths = np.array(path_fixture, dtype=np.int32)

    cost_distance_multiplier = np.array([cost_fixture for _ in range(len(path_fixture))],dtype=np.float64)
    cost_time_multiplier = np.array([cost_fixture for _ in range(len(path_fixture))],dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        cost_distance_multiplier = cost_distance_multiplier,
        cost_time_multiplier = cost_time_multiplier,
        num_units = 0,
        )

    for i in range(solution.num_vehicles):
        if solution.vehicle_num_services[i] > 0:
            assert solution.costs[i] > 0
            assert solution.costs[i] < 100
        else:
            assert solution.costs[i] == 0


def test_costs_with_constraints(path_fixture, cost_fixture):

    paths = np.array(path_fixture, dtype=np.int32)

    start_tw = np.array([[0],[0],[0],[-1],[-1],[-1]], dtype=float)
    end_tw = np.array([[0],[1],[1],[1],[1],[1]], dtype=float)

    cost_distance_multiplier = np.array([cost_fixture for _ in range(len(path_fixture))],dtype=np.float64)
    cost_time_multiplier = np.array([cost_fixture for _ in range(len(path_fixture))],dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        cost_distance_multiplier = cost_distance_multiplier,
        cost_time_multiplier = cost_time_multiplier,
        start_time_windows= start_tw,
        end_time_windows= end_tw,
        num_units = 0,
        )

    for i in range(solution.num_vehicles):
        if solution.vehicle_num_services[i] > 0:
            assert solution.costs[i] > 100
        else:
            assert solution.costs[i] == 0


def test_costs_with_constraints_and_predecessors(cost_fixture):

    paths = np.array([[1,2,-1,-1,-1], [4,5,3,-1,-1], [-1,-1,-1,-1,-1]], dtype=np.int32)

    start_tw = np.array([[0],[0],[0],[-1],[-1],[-1]], dtype=float)
    end_tw = np.array([[0],[1],[1],[1],[1],[1]], dtype=float)

    cost_distance_multiplier = np.array([cost_fixture for _ in range(3)],dtype=np.float64)
    cost_time_multiplier = np.array([cost_fixture for _ in range(3)],dtype=np.float64)
    predecessor_successor_gap = np.array([[1,2,100,-1], [2,3,-1, -1],[3,2,20, 21]], dtype= np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        cost_distance_multiplier = cost_distance_multiplier,
        cost_time_multiplier = cost_time_multiplier,
        start_time_windows= start_tw,
        end_time_windows= end_tw,
        predecessor_successor_gap=predecessor_successor_gap,
        num_units = 0,
        )

    for i in range(solution.num_vehicles):
        if solution.vehicle_num_services[i] > 0:
            assert solution.costs[i] > 100
            assert solution.service_predecessors_cost > 0
        else:
            assert solution.costs[i] == 0
