import pytest
import numpy as np
from fastvrpy.utils import *
from fastvrpy.core.solutions.cvrptw import CVRPTW

vehicle_start_index = np.array([0,0], dtype=np.int32)
vehicle_end_index = np.array([0,0], dtype=np.int32)
paths = np.array([[1,2,3,4,5]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)

problem = {
    "services" : [
        {
            "matrixIndex" : 0
        },
        {
            "matrixIndex" : 1
        },
        {
            "matrixIndex" : 2
        },
        {
            "matrixIndex" : 3
        },
        {
            "matrixIndex" : 3
        }
    ],
    "vehicles" : [
        {
            "matrixIndex" : 0
        }
    ]
}


def test_process_initial_solution():

    initial_paths = process_initial_solution(2, time_matrix[0], [0])
    assert np.array_equal(initial_paths, np.array( [[0,1,2, 3,-1,-1],
                                                    [4,5,-1,-1,-1,-1]]))

def test_solution_grouping():
    vehicle_start_index = np.array([5],dtype=np.int32)
    vehicle_end_index = np.array([5],dtype=np.int32)

    durations = np.array([1 for i in range(6)],dtype=np.float64)
    setup_durations = np.array([1 for i in range(6)],dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index = vehicle_end_index,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        durations = durations,
        setup_durations = setup_durations
    )
    groups = solution_grouping(solution, 3, problem)
    assert groups == [[0],[1],[2],[3,4]]



def test_cluster_bundle():

    groups = [[0],[1,2,3],[4,5]]

    vehicle_start_index = np.array([0],dtype=np.int32)
    vehicle_end_index = np.array([0],dtype=np.int32)

    durations = np.array([1 for i in range(6)],dtype=np.float64)
    setup_durations = np.array([1 for i in range(6)],dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index   = vehicle_end_index,
        num_units = 0,
        durations = durations,
        setup_durations = setup_durations
    )
    reduced_solution = cluster_bundle(solution, groups)

    assert np.array_equal(reduced_solution.vehicle_start_index, vehicle_start_index)
    assert np.array_equal(reduced_solution.vehicle_end_index, vehicle_end_index)
    assert np.array_equal(reduced_solution.durations, numpy.array([1,3,2]))
    assert np.array_equal(reduced_solution.setup_durations, numpy.array([1,3,2]))


def test_cluster_bundle_but_different_setup_durations():

    groups = [[0],[1,2,3],[4,5]]

    distance_matrix = np.array([   [[0,1,5,10,15,20],
                                    [1,0,2,4,6,8],
                                    [5,2,0,1,2,3],
                                    [10,4,1,0,10,20],
                                    [15,6,2,10,0,0],
                                    [20,8,3,20,0,0],]], dtype=np.float64)

    vehicle_start_index = np.array([0],dtype=np.int32)
    vehicle_end_index = np.array([0],dtype=np.int32)

    durations = np.array([1 for i in range(6)],dtype=np.float64)
    setup_durations = np.array([1 for i in range(6)],dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index   = vehicle_end_index,
        num_units = 0,
        durations = durations,
        setup_durations = setup_durations
    )
    reduced_solution = cluster_bundle(solution, groups)

    assert np.array_equal(reduced_solution.vehicle_start_index, vehicle_start_index)
    assert np.array_equal(reduced_solution.vehicle_end_index, vehicle_end_index)
    assert np.array_equal(reduced_solution.durations, numpy.array([1,3,2]))
    assert np.array_equal(reduced_solution.setup_durations, numpy.array([1,3,1]))
