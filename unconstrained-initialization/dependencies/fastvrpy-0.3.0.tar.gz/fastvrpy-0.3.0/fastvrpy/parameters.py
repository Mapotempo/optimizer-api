moves_parameters = {
            "OPT2" : {
                "Called" : True
            },
            "SWAP" : {
                "Called" : True,
                "KMax" : 1,
            },
            "RELOCATE" : {
                "Called" : True,
                "KMax" : 1,
            },
            "INTER_VECTOR_SWAP" : {
                "Called" : True,
                "KMax" : 1,
            },
            "INTER_VECTOR_RELOCATE" : {
                "Called" : True,
                "KMax" : 1,
            },
            "VECTOR_RELOCATE" : {
                "Called" : True,
                "KMax" : 1,
            },
            "ASSIGN" : {
                "Called" : False,
            },
            "UNASSIGN_SWAP" : {
                "Called" : False,
            },
        }


MAXTRY = 1000