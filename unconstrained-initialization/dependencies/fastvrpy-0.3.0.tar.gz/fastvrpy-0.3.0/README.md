To install the package :

- Install poetry
    pip install poetry

- Open the virtual env shell
    python -m poetry shell

- In the virtual env shell, Install all packages
    poetry install


To build the package:

- Add version tag on git (Major.Minor.Patch)

- Update version on poetry
    poetry version $(git describe --tags --abbrev=0)

- Build package
    python setup.py bdist_wheel to build whl
    python setup.py sdist to build tar.gz (not compiled)

- Amend last commit to integrate the new version

