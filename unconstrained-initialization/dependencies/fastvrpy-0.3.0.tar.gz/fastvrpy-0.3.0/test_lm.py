import numpy
import time
import random
from fastvrpy.core.solutions import cvrptw
from sklearn.metrics import pairwise_distances
import fastvrpy.solver as solver

from fastvrpy.utils import *

import logging as log
log_config()

log.info("---------------------------------------------")
log.info("STARTING NEW INITIALIZATION JOB")


tic = time.time()

POINTS = 50
SERVICE_PER_CMD = 50
SIZE = POINTS * SERVICE_PER_CMD
REAL_NUM_VEHICLE = 5
MAX_CAPACITY = 30
NUM_ITER = 100000000
CENTER_COORDINATES = (50.62712812120101, 3.130601200117362) #Villeneuve d'Ascq
MULTI_TOUR = 20
CAPACITY_UNIT = 1

NUM_VEHICLE = REAL_NUM_VEHICLE*MULTI_TOUR*2

log.info("Generate points")
points = [generate_point(70, CENTER_COORDINATES) for _ in range(POINTS)]

#Select time window of all points
point_tw = [random.choice([0,1])*3600*24 + random.choice([8,13])*3600 for _ in range(POINTS)]
start_tw = []
services = []

for service in range(SIZE):
    point_index = random.choice(range(POINTS))
    services.append(points[point_index])
    start_tw.append(point_tw[point_index])

start_tw.insert(0,0) #Store begin at 0 
services.insert(0,CENTER_COORDINATES) #Store at 0 

end_tw = []
for start in start_tw:
    end_tw.append(start + 5*3600 if start == 13 else start + 3600*random.choice([5,10]))
start_tw = numpy.array(start_tw, dtype=float)
end_tw = numpy.array(end_tw, dtype=float)


X = numpy.array(services)

log.info("Init parameters")
# path_init = list(range(1,SIZE+1))

random.seed(22021993)
numpy.random.seed(22021993)

#Setup duration at one address
setup_durations = [900 for _ in range(SIZE)]
setup_durations.insert(0,0) #The duration at the store (index 0)
setup_durations = numpy.array(setup_durations, dtype=numpy.float64)

#Stop duration
durations = [0 for _ in range(SIZE)]
durations.insert(0,0) #The duration at the store (index 0)
durations = numpy.array(durations, dtype=numpy.float64)

#Service volume occupancy
services_volume = [CAPACITY_UNIT for _ in range(SIZE)]
services_volume.insert(0,0) #The duration at the store (index 0)
services_volume = numpy.array(services_volume, dtype=numpy.float64)

log.info("Caculate Distance Matrix")
#Distances and time matrix
distance_matrix = pairwise_distances(X=X)*111*1000 #In meters
time_matrix = distance_matrix/ 0.02 /1000 #50 km/h mean speed (in seconds)

distance_matrix = numpy.array([distance_matrix])
time_matrix = numpy.array([time_matrix])


#Cost factors
cost_distance_multiplier = numpy.array([0.3 for _ in range(NUM_VEHICLE)])
cost_time_multiplier = numpy.array([15.0 for _ in range(NUM_VEHICLE)])
vehicle_capacity = numpy.array([MAX_CAPACITY for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
previous_vehicle = numpy.array([ -1 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)
vehicle_start_time_window = numpy.array([6*3600 for _ in range(int(NUM_VEHICLE/2))] + [6*3600 + 24*3600 for _ in range(int(NUM_VEHICLE/2))], dtype=numpy.float64)
vehicle_end_time_window = numpy.array([20*3600 for _ in range(int(NUM_VEHICLE/2))] + [20*3600 + 24*3600 for _ in range(int(NUM_VEHICLE/2))], dtype=numpy.float64)
vehicle_max_distance = numpy.array([-1 for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_fixed_costs = numpy.array([0 for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_overload_multiplier = numpy.array([10 for _ in range(NUM_VEHICLE)], dtype=numpy.float64)


counter = 0

for index in range(previous_vehicle.size):
    if counter != 0:
        previous_vehicle[index] = index - 1
        if counter == MULTI_TOUR-1:
            counter = 0
        else:
            counter += 1
    else:
        counter += 1
        
    
paths = process_initial_solution(NUM_VEHICLE, time_matrix[0])

solution = cvrptw.CVRPTW(
    paths = paths, 
    distance_matrix = distance_matrix, 
    time_matrix = time_matrix,
    start_time_windows = start_tw, 
    end_time_windows = end_tw, 
    durations = durations,
    setup_durations = setup_durations,
    services_volume = services_volume,
    cost_distance_multiplier = cost_distance_multiplier, 
    cost_time_multiplier = cost_time_multiplier,
    vehicle_capacity = vehicle_capacity,
    previous_vehicle = previous_vehicle,
    vehicle_max_distance = vehicle_max_distance,
    vehicle_fixed_costs = vehicle_fixed_costs,
    vehicle_overload_multiplier = vehicle_overload_multiplier,
    vehicle_start_time_window = vehicle_start_time_window,
    vehicle_end_time_window = vehicle_end_time_window)


solver.optimize(
    solution= solution,
    max_execution_time= 10*60,
    problem =None,
    groups_max_capacity=MAX_CAPACITY)

log.info("ENDING INITIALIZATION JOB")