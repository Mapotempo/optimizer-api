# -*- coding: utf-8 -*-
from setuptools import setup, find_packages
import numpy
import shutil
import os
from Cython.Build import cythonize, build_ext
from setuptools import Extension


#All folders to add to the package
packages = \
['fastvrpy',
 'fastvrpy.core',
 'fastvrpy.core.solutions',
 'fastvrpy.core.moves',
 'fastvrpy.core.cleaning',
]

package_data = \
{'': ['*']}

install_requires = \
['Cython>=0.29.27,<0.30.0', 'numpy>=1.21.6']

include_dirs=[numpy.get_include()]

setup_kwargs = {
    'name': 'fastvrpy',
    'version': '0.3.0',
    'description': 'Package to solve VRP problems quickly with unconstrained local search algorithms',
    'long_description': None,
    'author': 'Guillaume Maran, Pierre Graber',
    'author_email': 'guillaume.maran@woopit.fr',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': find_packages(),
    'package_data': package_data,
    'install_requires': install_requires,
    'include_dirs': include_dirs,
    'python_requires': '>=3.8,<4.0',
}


extensions = [
    Extension("fastvrpy.core.algorithm", ["fastvrpy/core/algorithm.pyx"], ),
    Extension("fastvrpy.core.solutions.cvrptw", ["fastvrpy/core/solutions/cvrptw.pyx"], ),
    Extension("fastvrpy.core.solutions.solution", ["fastvrpy/core/solutions/solution.pyx"], ),
    Extension("fastvrpy.core.solutions.global_constraints", ["fastvrpy/core/solutions/global_constraints.pyx"], ),
    Extension("fastvrpy.core.cleaning.clean_vehicles", ["fastvrpy/core/cleaning/clean_vehicles.pyx"], ),
    Extension("fastvrpy.core.cleaning.clean_services", ["fastvrpy/core/cleaning/clean_services.pyx"], ),
    Extension("fastvrpy.core.utils.operators", ["fastvrpy/core/utils/operators.pyx"], ),
    Extension("fastvrpy.core.utils.evaluation_utils", ["fastvrpy/core/utils/evaluation_utils.pyx"], ),
    Extension("fastvrpy.core.moves.move", ["fastvrpy/core/moves/move.pyx"], ),
    Extension("fastvrpy.core.moves.opt2", ["fastvrpy/core/moves/opt2.pyx"], ),
    Extension("fastvrpy.core.moves.swap", ["fastvrpy/core/moves/swap.pyx"], ),
    Extension("fastvrpy.core.moves.relocate", ["fastvrpy/core/moves/relocate.pyx"], ),
    Extension("fastvrpy.core.moves.inter_swap", ["fastvrpy/core/moves/inter_swap.pyx"], ),
    Extension("fastvrpy.core.moves.inter_relocate", ["fastvrpy/core/moves/inter_relocate.pyx"], ),
    Extension("fastvrpy.core.moves.vector_relocate", ["fastvrpy/core/moves/vector_relocate.pyx"], ),
    Extension("fastvrpy.core.moves.assign", ["fastvrpy/core/moves/assign.pyx"], ),
    Extension("fastvrpy.core.moves.unassigned_swap", ["fastvrpy/core/moves/unassigned_swap.pyx"], ),
]

# gcc arguments hack: enable optimizations
os.environ['CFLAGS'] = '-O3'

# Build
setup_kwargs.update({
    'ext_modules': cythonize(
        extensions,
        language_level=3,
        annotate=True,
        gdb_debug=True,
        compiler_directives={'linetrace': True},
    ),
    'cmdclass': {'build_ext': build_ext},
    'include_dirs': [numpy.get_include()],
})

setup(**setup_kwargs)
