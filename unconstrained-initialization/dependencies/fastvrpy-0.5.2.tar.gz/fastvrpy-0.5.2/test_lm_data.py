import numpy
import time
import random
from fastvrpy.core.solutions import cvrptw
from sklearn.metrics import pairwise_distances
import fastvrpy.solver as solver
import json
import pandas as pd
from fastvrpy.utils import *

import logging as log
log_config()

log.info("---------------------------------------------")
log.info("STARTING NEW INITIALIZATION JOB")


tic = time.time()

MAX_CAPACITY = [15000, 30]

formated_data = {}
store_points = []
store_num_points = []
store_num_services = []
with open("data/lm_data.json") as input:
    data = json.load(input)

    stores = [cmd["store"]["storeName"] for cmd in data]
    stores = list(set(stores))

    index = 0

    for cmd_index, cmd in enumerate(data):
        store_point = (cmd["store"]["address"]["latitude"], cmd["store"]["address"]["longitude"])
        store = cmd["store"]["storeName"]
        delivery_point = (cmd["customer"]["deliveryAddress"]["latitude"], cmd["customer"]["deliveryAddress"]["longitude"])
        total_cmd = 0
        if "merchandiseListToBeDelivered" in cmd:
            for product in cmd["merchandiseListToBeDelivered"]:
                if store not in formated_data:
                    formated_data[store] = []
                    store_points.append(store_point)
                
                total_weight = float(product["totalWeight"])
                total_volume = float(product["totalVolume"])
                unit_weight = product["specifications"]["weigth"]
                unit_volume = product["specifications"]["volume"]

                total_cmd += total_weight

                quantity = int(float(product["quantity"]))
                if total_weight <= MAX_CAPACITY[0] and total_volume <= MAX_CAPACITY[1]:
                    unit_weight = product["totalWeight"]
                    unit_volume = product["totalVolume"]
                    quantity = 1

                for i in range(quantity) :
                    formated_data[store].append({
                        "service_id" : index,
                        "cmd_id" : cmd_index,
                        "volume" : float(unit_volume),
                        "weight" : float(unit_weight),
                        "point" : delivery_point
                    })
                    index += 1

    for key, value in formated_data.items():
        points =  list(set([service["point"] for service in value]))
        total_volume = sum(service["volume"] for service in value)
        total_weight = sum(service["weight"] for service in value)

        store_num_points.append(len(points)) 
        store_num_services.append(len(value)) 

#mag = "Merlimont - Le-Touquet-Paris-Plage"
mag = "Saint-Doulchard - Bourges"
#mag = "Villeneuve-d'Ascq - Lille"
#mag = "Lesquin - Lille"

#for mag in formated_data.keys():

print(f"--------- {mag} -----------")
mag_index = list(formated_data.keys()).index(mag)
data = formated_data[mag]

POINTS = store_num_points[mag_index]
SIZE = store_num_services[mag_index]
STORE_INDEXES = [0]

print(f"Num points : {POINTS} - Num parcels : {SIZE}")

if POINTS > 17:
    REAL_NUM_VEHICLE = 2
else:
    REAL_NUM_VEHICLE = 1

REAL_NUM_VEHICLE = 2
NUM_ITER = 100000000
CENTER_COORDINATES = store_points[mag_index] #Villeneuve d'Ascq
MULTI_TOUR = 15

NUM_VEHICLE = REAL_NUM_VEHICLE*MULTI_TOUR

log.info("Generate points")
points = [cmd["point"] for cmd in data]
points = list(set(points))

# import plotly.express as px


# df = pd.DataFrame(points, columns = ['lat','lon'])

# fig = px.scatter_mapbox(df, lat="lat", lon="lon", zoom=8, height=600)
# fig.update_layout(mapbox_style="open-street-map")
# fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
# fig.show()

#Select time window of all points
point_tw = [random.choice([0])*3600*24 + random.choice([8,12])*3600 for _ in range(POINTS)]
start_tw = []
services = []

for service in range(SIZE):
    point_index = points.index(data[service]["point"])
    services.append(points[point_index])
    start_tw.append([point_tw[point_index]])

start_tw.insert(0,[0]) #Store begin at 0 
services.insert(0,CENTER_COORDINATES) #Store at 0 

end_tw = []
for start in start_tw:
    end_tw.append([start[0] + 6*3600])
start_tw = numpy.array(start_tw, dtype=float)
end_tw = numpy.array(end_tw, dtype=float)


X = numpy.array(services)

log.info("Init parameters")
# path_init = list(range(1,SIZE+1))

random.seed(22021993)
numpy.random.seed(22021993)

#Setup duration at one address
setup_durations = [900 for _ in range(SIZE)]
setup_durations.insert(0,0) #The duration at the store (index 0)
setup_durations = numpy.array(setup_durations, dtype=numpy.float64)

#Stop duration
durations = [0 for _ in range(SIZE)]
durations.insert(0,0) #The duration at the store (index 0)
durations = numpy.array(durations, dtype=numpy.float64)

#Service volume occupancy
services_volume = [[data[service]["weight"], data[service]["volume"]] for service in range(SIZE)]
services_volume.insert(0,[0,0]) #The duration at the store (index 0)
services_volume = numpy.array(services_volume, dtype=numpy.float64)

log.info("Caculate Distance Matrix")
#Distances and time matrix
distance_matrix = pairwise_distances(X=X)*111*1000 #In meters
time_matrix = distance_matrix/ 0.013 /1000 #50 km/h mean speed (in seconds)

distance_matrix = numpy.array([distance_matrix])
time_matrix = numpy.array([time_matrix])


#Cost factors
cost_distance_multiplier = numpy.array([0.3 for _ in range(NUM_VEHICLE)])
cost_time_multiplier = numpy.array([15.0 for _ in range(NUM_VEHICLE)])
vehicle_capacity = numpy.array([MAX_CAPACITY for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
previous_vehicle = numpy.array([ -1 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)
vehicle_start_time_window = numpy.array([6*3600 for _ in range(int(NUM_VEHICLE))], dtype=numpy.float64)
vehicle_end_time_window = numpy.array([20*3600 for _ in range(int(NUM_VEHICLE))], dtype=numpy.float64)
vehicle_max_distance = numpy.array([-1 for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_fixed_costs = numpy.array([0 for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_overload_multiplier = numpy.array([[2, 10] for _ in range(NUM_VEHICLE)], dtype=numpy.float64)
vehicle_start_index = numpy.array([0 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)
vehicle_end_index = numpy.array([0 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)

counter = 0

for index in range(previous_vehicle.size):
    if counter != 0:
        previous_vehicle[index] = index - 1
        if counter == MULTI_TOUR-1:
            counter = 0
        else:
            counter += 1
    else:
        counter += 1
        
    
paths = process_initial_solution(NUM_VEHICLE, time_matrix[0], STORE_INDEXES)

solution = cvrptw.CVRPTW(
    paths = paths, 
    distance_matrix = distance_matrix, 
    time_matrix = time_matrix,
    start_time_windows = start_tw, 
    end_time_windows = end_tw, 
    durations = durations,
    setup_durations = setup_durations,
    services_volumes = services_volume,
    cost_distance_multiplier = cost_distance_multiplier, 
    cost_time_multiplier = cost_time_multiplier,
    vehicle_capacities = vehicle_capacity,
    previous_vehicle = previous_vehicle,
    vehicle_max_distance = vehicle_max_distance,
    vehicle_fixed_costs = vehicle_fixed_costs,
    vehicle_overload_multiplier = vehicle_overload_multiplier,
    vehicle_start_time_window = vehicle_start_time_window,
    vehicle_end_time_window = vehicle_end_time_window,
    vehicle_start_index = vehicle_start_index,
    vehicle_end_index = vehicle_end_index,
    num_units = 2)


solver.optimize(
    solution= solution,
    max_execution_time= 1*60,
    problem =None,
    groups_max_capacity=MAX_CAPACITY[0])


print("Unassigned : ", len(solution.unassigned))

log.info("ENDING INITIALIZATION JOB")

    # prev = -1

    # for v in range(solution.paths.shape[0]):
    #     print("Tour", v, numpy.array(solution.vehicle_occupancies[v]))
    #     for i in range(solution.paths.shape[1]):
    #         service = solution.paths[v, i]
    #         if service == -1:
    #             break
            
    #         cmd = formated_data[mag][service-1]["cmd_id"]
    #         if cmd != prev:
    #             print(formated_data[mag][service-1]["cmd_id"], formated_data[mag][service-1]["point"], solution.starts[v, i], numpy.array(solution.end_time_windows[service]))
    #         prev = cmd