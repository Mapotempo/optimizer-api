import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3,4,5]], dtype=np.int32)
service_matrice_index = np.array([0,1,2,3,4,5], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1,1],
                             [1,0,1,1,1,1,1],
                             [1,1,0,1,1,1,1],
                             [1,1,1,0,1,1,1],
                             [1,1,1,1,0,1,1],
                             [1,1,1,1,1,1,1],
                             [1,1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20, 12],
                         [1,0,2,4,6,8, 12],
                         [5,2,0,1,2,3, 12],
                         [10,4,1,0,10,20,13],
                         [15,6,2,10,0,5,4],
                         [20,8,3,20,5,1,1],
                         [20,8,3,20,5,1,0]]], dtype=np.float64)

def test_ends():
    solution = CVRPTW(
        paths = paths,
        service_matrix_index = service_matrice_index,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )
    assert np.array_equal(np.array([[0,1,3,4,14,19,0]]), solution.starts)

def test_ends_with_duration():

    durations = np.array([0,1,1,1,1,1], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        durations = durations
        )
    assert np.array_equal(np.array([[0,1,4,6,17,23,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[0,2,5,7,18,24,0]]), np.array(solution.ends))


def test_ends_with_avance():

    start_tw = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,10,11,21,26,0]]), np.array(solution.ends))

def test_ends_with_avance_and_durations():

    start_tw  = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)

    durations = np.array([0,1,1,1,1,1], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        durations=durations
        )

    assert np.array_equal(np.array([[0,1,10,12,23,29,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[0,2,11,13,24,30,0]]), np.array(solution.ends))


def test_ends_with_avance_multitw():

    start_tw    = np.array([[0, -1],[1, -1],[10, 15],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw      = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,10,15,25,30,0]]), np.array(solution.ends))

def test_ends_with_avance_multitw_and_durations():

    start_tw    = np.array([[0, -1],[1, -1],[10, 15],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw      = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)
    durations = np.array([0,1,1,1,1,1], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        durations = durations
        )

    assert np.array_equal(np.array([[0,1,10,15,26,32,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[0,2,11,16,27,33,0]]), np.array(solution.ends))

def test_ends_with_avance_multitw_and_durations_and_setup():

    start_tw        = np.array([[0, -1],[1, -1],[10, 15],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw          = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)
    durations       = np.array([0,1,1,1,1,1], dtype=np.float64)
    setup_durations = np.array([0,1,1,1,1,1], dtype=np.float64)

    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        start_time_windows  = start_tw,
        end_time_windows    = end_tw,
        num_units           = 0,
        durations           = durations,
        setup_durations     = setup_durations
        )

    assert np.array_equal(np.array([[0,2,10,15,27,34,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[0,3,11,16,28,35,0]]), np.array(solution.ends))

def test_ends_with_avance_multitw_and_durations_and_setup_but_same_point():

    distance_matrix_same_point = np.array([[[0,0,1,1,1,1,1],
                                            [0,0,1,1,1,1,1],
                                            [1,1,0,1,1,1,1],
                                            [1,1,1,0,1,1,1],
                                            [1,1,1,1,0,1,1],
                                            [1,1,1,1,1,0,1],
                                            [1,1,1,1,1,1,0]]], dtype=np.float64)

    start_tw        = np.array([[0, -1],[1, -1],[10, 15],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw          = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)
    durations       = np.array([0,1,1,1,1,1], dtype=np.float64)
    setup_durations = np.array([0,1,1,1,1,1], dtype=np.float64)

    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix_same_point,
        time_matrix         = time_matrix,
        start_time_windows  = start_tw,
        end_time_windows    = end_tw,
        num_units           = 0,
        durations           = durations,
        setup_durations     = setup_durations
        )

    assert np.array_equal(np.array([[0,1,10,15,27,34,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[0,2,11,16,28,35,0]]), np.array(solution.ends))


def test_ends_with_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )

    assert np.array_equal(np.array([[100,101,103,104,114,119,0]]), np.array(solution.starts))


def test_ends_with_avance_multitw_and_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[115, 115],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[110, 120],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )

    assert np.array_equal(np.array([[100,101,110,115,125,130,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[100,101,110,115,125,130,0]]), np.array(solution.ends))

def test_ends_with_avance_multitw_and_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[115, 115],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[110, 120],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )

    assert np.array_equal(np.array([[100,101,110,115,125,130,0]]), np.array(solution.starts))
    assert np.array_equal(np.array([[100,101,110,115,125,130,0]]), np.array(solution.ends))
