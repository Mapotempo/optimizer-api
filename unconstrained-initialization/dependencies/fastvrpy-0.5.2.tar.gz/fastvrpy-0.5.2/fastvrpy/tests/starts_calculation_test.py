import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3,4,5]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)





def test_starts():

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,3,4,14,19,0]]), solution.starts)


def test_starts_with_avance():

    start_tw = np.array([[0],[1],[10],[-1],[-1],[-1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,10,11,21,26,0]]), np.array(solution.starts))


def test_starts_with_avance_multitw():

    start_tw = np.array([[0, -1],[1, -1],[10, 15],[5, 15],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,10,15,25,30,0]]), np.array(solution.starts))


def test_starts_with_late_multitw():

    start_tw = np.array([[0, -1],[1, -1],[10, 15],[5, 15],[5, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[10, 20],[20, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    #We are late at the 4th service, but this change nothing on the ETA
    assert np.array_equal(np.array([[0,1,10,15,25,30,0]]), np.array(solution.starts))

    #We we need to know that we are late!
    assert np.array_equal(np.array([5]), np.array(solution.vehicle_max_late))




def test_starts_with_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )

    assert np.array_equal(np.array([[100,101,103,104,114,119,0]]), np.array(solution.starts))


def test_starts_with_avance_multitw_and_vehicle_tw():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    start_tw = np.array([[0, -1],[1, -1],[110, 115],[115, 115],[-1, -1],[-1, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[110, 120],[-1, -1],[-1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )


    assert np.array_equal(np.array([[100,101,110,115,125,130,0]]), np.array(solution.starts))


def test_starts_with_avance_multitw_and_vehicle_tw_v2():

    vehicle_start_time_window = np.array([100], dtype=np.float64)

    start_tw = np.array([[0, -1, -1],[1, -1, -1],[110, 115, -1],[115, 115, -1],[-1, -1, -1],[-1, -1, -1]], dtype=float)
    end_tw = np.array([[-1, -1, -1],[-1, -1, -1],[-1, -1, -1],[110, 120, -1],[-1, -1,-1],[-1, -1, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        vehicle_start_time_window = vehicle_start_time_window,
        num_units = 0,
        )


    assert np.array_equal(np.array([[100,101,110,115,125,130,0]]), np.array(solution.starts))


def test_starts_with_setup_durations():

    setup_durations = np.array([0,10,10,10,10,10], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        setup_durations = setup_durations,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,11,23,34,54,69,0]]), np.array(solution.starts))


def test_starts_with_setup_durations_with_no_repetition():

    time_matrix = np.array([[[0,1,5,10,15,20],
                            [1,0,0,4,6,8],
                            [5,2,0,0,2,3],
                            [10,4,1,0,10,20],
                            [15,6,2,10,0,5],
                            [20,8,3,20,5,0],]], dtype=np.float64)
    distance_matrix = np.array([[[0,1,1,1,1,1],
                                [1,0,0,1,1,1],
                                [1,1,0,0,1,1],
                                [1,1,1,0,0,1],
                                [1,1,1,1,0,1],
                                [1,1,1,1,1,0],]], dtype=np.float64)

    setup_durations = np.array([0,10,10,10,10,10], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        setup_durations = setup_durations,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,11,11,11,21,36,0]]), np.array(solution.starts))


def test_starts_with_setup_durations_with_no_repetition_and_durations():

    time_matrix = np.array([[[0,1,5,10,15,20],
                            [1,0,0,4,6,8],
                            [5,2,0,0,2,3],
                            [10,4,1,0,10,20],
                            [15,6,2,10,0,5],
                            [20,8,3,20,5,0],]], dtype=np.float64)
    distance_matrix = np.array([[[0,1,1,1,1,1],
                                [1,0,0,1,1,1],
                                [1,1,0,0,1,1],
                                [1,1,1,0,0,1],
                                [1,1,1,1,0,1],
                                [1,1,1,1,1,0],]], dtype=np.float64)

    setup_durations = np.array([0,10,10,10,10,10], dtype=np.float64)
    durations = np.array([0,2,3,4,5,6], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        setup_durations = setup_durations,
        durations = durations,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,11,13,16,30,50,0]]), np.array(solution.starts))


def test_starts_with_durations_and_setup_durations():


    setup_durations = np.array([0,10,10,10,10,10], dtype=np.float64)

    durations = np.array([0,2,3,4,5,6], dtype=np.float64)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        setup_durations = setup_durations,
        durations = durations,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,11,25,39,63,83,0]]), np.array(solution.starts))


def test_starts_2_vehicles():

    paths = np.array([[1,2,3,4,5], [5,4,3,-1,-1]], dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )
    assert np.array_equal(np.array([[0,1,3,4,14,19,0], [0,20,25,35,0,0,0]]), solution.starts)

def test_starts_2_vehicles_2_stores():

    paths = np.array([[2,3,4,5,-1], [5,4,3,-1,-1]], dtype=np.int32)

    #Let's play a bit the multiple stores !
    vehicle_start_index = np.array([0,1], dtype=np.int32)
    vehicle_end_index = np.array([1,0], dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index = vehicle_end_index,
        num_units = 0,
        )
    assert np.array_equal(np.array([[0,5,6,16,21,0,0], [0,8,13,23,0,0,0]]), np.array(solution.starts))
