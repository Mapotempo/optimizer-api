import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW
from fastvrpy.core import algorithm




distance_matrix = np.array([[[0,1,2,3,4,5],
                            [6,0,7,8,9,10],
                            [11,12,0,1000,14,15],
                            [16,17,18,0,0,0],
                            [19,20,21,22,0,23],
                            [2,2,3,24,25,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1000,2,3],
                        [10,4,1,0,0,0],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)

@pytest.fixture(params=[
    [[1,2,3,4,5]],
    [[1,2,3,4,5], [-1,-1,-1,-1,-1]],
    [[1,2,3,-1,-1], [4,5,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,-1,-1,-1], [3,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,3,-1,-1], [-1,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,3,-1,-1], [-1,-1,-1,-1,-1], [-1,-1,-1,-1,-1]],
    ])
def path_fixture(request):
    return request.param


@pytest.fixture(params=[True, False])
def previous_fixture(request):
    return request.param

@pytest.fixture(params=[0, 1, 2])
def start_mode_fixture(request):
    return request.param

def test_calc_latest_start_full_cosnstraints(path_fixture, previous_fixture, start_mode_fixture):
    """
    Here we basically check if we optimize something
    """

    moves_parameters = {
        "OPT2" : {
            "Called" : True
        },
        "SWAP" : {
            "Called" : True,
            "KMax" : 1,
        },
        "RELOCATE" : {
            "Called" : True,
            "KMax" : 1,
        },
        "INTER_VECTOR_SWAP" : {
            "Called" : True,
            "KMax" : 1,
        },
        "INTER_VECTOR_RELOCATE" : {
            "Called" : True,
            "KMax" : 1,
        },
        "VECTOR_RELOCATE" : {
            "Called" : True,
            "KMax" : 1,
        },
        "ASSIGN" : {
            "Called" : False,
        },
        "UNASSIGN_SWAP" : {
            "Called" : False,
        },
    }

    num_vehicle = len(path_fixture)
    paths = np.array(path_fixture, dtype=np.int32)
    start_tw = np.array([[0],[0],[0],[-1],[-1],[-1]], dtype=float)
    end_tw = np.array([[0],[10],[15],[21],[31],[26]], dtype=float)
    durations = np.array([0,1,2,3,4,5], dtype=np.float64)
    setup_durations = np.array([0,10,12,13,14,15], dtype=np.float64)
    services_volumes = np.array([[0],[1],[2],[1],[2],[1]], dtype=np.float64)
    cost_distance_multiplier = np.array([0.8 for _ in range(num_vehicle)], dtype=np.float64)
    cost_time_multiplier = np.array([1.5 for _ in range(num_vehicle)], dtype=np.float64)
    vehicle_capacities = np.array([[7] for _ in range(num_vehicle)], dtype=np.float64)
    predecessor_successor_gap = np.array([[1,2,3000,-1], [2,4,720, 1000]], dtype=np.int32)

    if previous_fixture:
        previous_vehicle = [-1]
        for i in range(1,num_vehicle):
            previous_vehicle.append(i - 1)
        previous_vehicle = np.array(previous_vehicle, dtype=np.int32)

    else:
        previous_vehicle = np.full(num_vehicle, -1, dtype=np.int32)

    vehicle_max_distance = np.array([100 for _ in range(num_vehicle)], dtype=np.float64)
    vehicle_fixed_costs = np.array([4 for _ in range(num_vehicle)], dtype=np.float64)
    vehicle_overload_multiplier = np.array([[1] for _ in range(num_vehicle)], dtype=np.float64)
    vehicle_start_time_window = np.array([0 for _ in range(num_vehicle)], dtype=np.float64)
    vehicle_end_time_window = np.array([150 for _ in range(num_vehicle)], dtype=np.float64)
    vehicle_start_index = np.array([0 for _ in range(num_vehicle)], dtype=np.int32)
    vehicle_end_index = np.array([0 for _ in range(num_vehicle)], dtype=np.int32)
    vehicle_start_mode = np.array([start_mode_fixture for _ in range(num_vehicle)], dtype=np.int32)
    


    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        durations = durations,
        setup_durations = setup_durations,
        services_volumes = services_volumes,
        cost_distance_multiplier = cost_distance_multiplier,
        cost_time_multiplier = cost_time_multiplier,
        vehicle_capacities = vehicle_capacities,
        previous_vehicle = previous_vehicle,
        vehicle_max_distance = vehicle_max_distance,
        vehicle_fixed_costs = vehicle_fixed_costs,
        vehicle_overload_multiplier = vehicle_overload_multiplier,
        vehicle_start_time_window = vehicle_start_time_window,
        vehicle_end_time_window = vehicle_end_time_window,
        vehicle_start_index = vehicle_start_index,
        vehicle_end_index = vehicle_end_index,
        predecessor_successor_gap = predecessor_successor_gap,
        vehicle_start_mode = vehicle_start_mode,
        num_units = 0)


    algorithm.ils(
        solution = solution,
        max_time = 1,
        max_iteration = 100000,
        ls_max_iterations = 500,
        moves_parameters = moves_parameters,
        perturbation_rate = 5)

    cost = solution.total_cost

    assert np.all(np.array(solution.start_offset) == 0), f"np.all(solution.start_offset == 0) should be True before calc lastest start"

    algorithm.calc_latest_start(solution=solution, n_space=12)

    if cost > 0:
        if start_mode_fixture != 1:
            #We should not optimize nothing in that case
            assert np.all(np.array(solution.start_offset) == 0), f"np.all(solution.start_offset == 0) should be True if start mode is not 1"
            assert solution.total_cost == pytest.approx(cost, abs=0.001)
        else:
            if np.all(solution.start_offset == 0):
                assert solution.total_cost == pytest.approx(cost, abs=0.001)
            else:
                assert solution.total_cost <= cost + 0.001
    else:
        assert solution.total_cost == pytest.approx(cost, abs=0.001)
