import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW
from fastvrpy.core import algorithm

paths = np.array([[1,2,3]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                             [1,0,1,1,1,1],
                             [1,1,0,1,1,1],
                             [1,1,1,0,1,1],
                             [1,1,1,1,0,1],
                             [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                         [1,0,2,4,6,8],
                         [5,2,0,1,2,3],
                         [10,4,1,0,10,20],
                         [15,6,2,10,0,5],
                         [20,8,3,20,5,0],]], dtype=np.float64)

moves_parameters = {
        "OPT2" : {
            "Called" : True
        },
        "SWAP" : {
            "Called" : True,
            "KMax" : 1,
        },
        "RELOCATE" : {
            "Called" : True,
            "KMax" : 1,
        },
        "INTER_VECTOR_SWAP" : {
            "Called" : True,
            "KMax" : 1,
        },
        "INTER_VECTOR_RELOCATE" : {
            "Called" : True,
            "KMax" : 1,
        },
        "VECTOR_RELOCATE" : {
            "Called" : True,
            "KMax" : 1,
        },
        "ASSIGN" : {
            "Called" : True,
        },
        "UNASSIGN_SWAP" : {
            "Called" : True,
        },
    }

def test_unassigned_cost():
    unassigned = np.array([4,5,-1,-1,-1,-1], dtype=np.int32)
    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        unassigned_services = unassigned
        )
    solution.init_calculated_attributes()
    print(np.array(solution.unassigned_services))
    print(np.array(solution.paths))
    solution.evaluate(np.array([0], dtype=np.int32),False)
    algorithm.ils(
        solution = solution,
        max_time = 1,
        max_iteration = 100000,
        ls_max_iterations = 500,
        moves_parameters = moves_parameters,
        perturbation_rate = 5)
