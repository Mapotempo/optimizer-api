import pytest
import numpy as np
from fastvrpy.core.solutions.solution import Solution


@pytest.fixture(params=[True, False])
def previous_fixture(request):
    return request.param


def test_build_solution_no_services():
    paths = np.array([[-1,-1,-1,-1,-1]], dtype=np.int32)
    
    with pytest.raises(AttributeError):
        solution = Solution(
            paths = paths,
            distance_matrix = np.zeros((1,4, 4), dtype=np.float64),
            time_matrix = np.zeros((1,4, 4), dtype=np.float64),
            num_units = 0,
            )




@pytest.mark.parametrize("distance_matrix, time_matrix", [
    (np.zeros((1,4, 3), dtype=np.float64), np.zeros((2,4, 3), dtype=np.float64)), #Not square matrix
    (np.zeros((1,5, 5), dtype=np.float64), np.zeros((1,4, 4), dtype=np.float64)), #Not same matrix
    (np.zeros((2,5, 5), dtype=np.float64), np.zeros((1,5, 5), dtype=np.float64)), #Not same matrix
    (np.zeros((2,3, 3), dtype=np.float64), np.zeros((2,3, 3), dtype=np.float64)), #More services in paths than size of matrix
    (np.zeros((2,5, 5), dtype=np.float64), np.zeros((2,5, 5), dtype=np.float64)), #More services in paths than size of matrix
    ])
def test_build_solution_bad_matrix(distance_matrix, time_matrix):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        num_units = 0)

@pytest.mark.parametrize("start_time_windows", [
    np.zeros((5,2), dtype=np.float64),#Not square matrix
    np.zeros((4,1), dtype=np.float64), #Not same matrix
    np.zeros((7,2), dtype=np.float64), #Not same matrix
    np.zeros((1,1), dtype=np.float64), #More services in paths than size of matrix
    np.zeros((5,1), dtype=np.float64), #More services in paths than size of matrix
    ])
def test_build_solution_bad_start_time(start_time_windows):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    distance_matrix = np.zeros((2,6, 6), dtype=np.float64)
    time_matrix = np.zeros((2,6, 6), dtype=np.float64)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        start_time_windows = start_time_windows,
        num_units = 0)


@pytest.mark.parametrize("end_time_windows", [
    np.zeros((5,2), dtype=np.float64),#Not square matrix
    np.zeros((4,1), dtype=np.float64), #Not same matrix
    np.zeros((7,2), dtype=np.float64), #Not same matrix
    np.zeros((1,1), dtype=np.float64), #More services in paths than size of matrix
    np.zeros((5,1), dtype=np.float64), #More services in paths than size of matrix
    ])
def test_build_solution_bad_end_time(end_time_windows):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    distance_matrix = np.zeros((2,6, 6), dtype=np.float64)
    time_matrix = np.zeros((2,6, 6), dtype=np.float64)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        end_time_windows = end_time_windows,
        num_units = 0)


@pytest.mark.parametrize("durations", [
    np.zeros((5), dtype=np.float64),#Not square matrix
    np.zeros((4), dtype=np.float64), #Not same matrix
    np.zeros((7), dtype=np.float64), #Not same matrix
    np.zeros((1), dtype=np.float64), #More services in paths than size of matrix
    np.zeros((5), dtype=np.float64), #More services in paths than size of matrix
    ])
def test_build_solution_bad_durations(durations):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    distance_matrix = np.zeros((2,6, 6), dtype=np.float64)
    time_matrix = np.zeros((2,6, 6), dtype=np.float64)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        durations = durations,
        num_units = 0)


@pytest.mark.parametrize("setup_durations", [
    np.zeros((5), dtype=np.float64),#Not square matrix
    np.zeros((4), dtype=np.float64), #Not same matrix
    np.zeros((7), dtype=np.float64), #Not same matrix
    np.zeros((1), dtype=np.float64), #More services in paths than size of matrix
    np.zeros((5), dtype=np.float64), #More services in paths than size of matrix
    ])
def test_build_solution_bad_setup_durations(setup_durations):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    distance_matrix = np.zeros((2,6, 6), dtype=np.float64)
    time_matrix = np.zeros((2,6, 6), dtype=np.float64)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        setup_durations = setup_durations,
        num_units = 0)


@pytest.mark.parametrize("setup_durations", [
    np.zeros((5), dtype=np.float64),#Not square matrix
    np.zeros((4), dtype=np.float64), #Not same matrix
    np.zeros((7), dtype=np.float64), #Not same matrix
    np.zeros((1), dtype=np.float64), #More services in paths than size of matrix
    np.zeros((5), dtype=np.float64), #More services in paths than size of matrix
    ])
def test_build_solution_bad_setup_durations(setup_durations):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    distance_matrix = np.zeros((2,6, 6), dtype=np.float64)
    time_matrix = np.zeros((2,6, 6), dtype=np.float64)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        setup_durations = setup_durations,
        num_units = 0)


@pytest.mark.parametrize("predecessor_successor_gap", [
    np.array([[1,2,3000,4000], [2,3,10000, 720]], dtype=np.int32), #Max < min
    np.array([[1,2,3000,4000], [2,30,720, 1000]], dtype=np.int32), #Index out of bound
    np.array([[1,2,-1],], dtype=np.int32), #Not enough value
    np.array([[1,2,3000,-1,2], [2,30,720, 1000,2]], dtype=np.int32), #Too much values
    ])
def test_build_solution_bad_predecessor_successor_gap(predecessor_successor_gap):

    paths = np.array([[1,2,3,4,5]], dtype=np.int32)
    distance_matrix = np.zeros((2,6, 6), dtype=np.float64)
    time_matrix = np.zeros((2,6, 6), dtype=np.float64)

    with pytest.raises(AssertionError):
        Solution(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = time_matrix,
        predecessor_successor_gap = predecessor_successor_gap,
        num_units = 0)