import numpy
import timeit
import random
from fastvrpy.core.solutions import cvrptw
from fastvrpy.utils import *
import cProfile
import json
from sklearn.metrics import pairwise_distances
import fastvrpy.solver as solver
import logging as log

log_config()

random.seed(161803398)
numpy.random.seed(161803398)

log.info("---------------------------------------------")
log.info("STARTING NEW INITIALIZATION JOB")

SIZE = 1300
NUM_VEHICLE = 90
MAX_CAPACITY = [20]
NUM_ITER = 100000000
CENTER_COORDINATES = (48.71908797060985, 2.3072640438370553) #Chilly Mazarin
CAPACITY_UNIT = 1
STORE_INDEXES = [0]


log.info("Generate points")
points = [generate_point(75, CENTER_COORDINATES) for _ in range(SIZE)]
points.insert(0,CENTER_COORDINATES) #Store at 0 
X = numpy.array(points)

log.info("Init parameters")
# path_init = list(range(1,SIZE+1))


#Setup duration at one address
setup_durations = [0 for _ in range(SIZE)]
setup_durations.insert(0,0) #The duration at the store (index 0)
setup_durations = numpy.array(setup_durations, dtype=numpy.float64)

#Stop duration
durations = [60 for _ in range(SIZE)]
durations.insert(0,0) #The duration at the store (index 0)
durations = numpy.array(durations, dtype=numpy.float64)

#Service volume occupancy
services_volume = [[CAPACITY_UNIT] for _ in range(SIZE)]
services_volume.insert(0,[0]) #The duration at the store (index 0)
services_volume = numpy.array(services_volume, dtype=numpy.float64)

log.info("Caculate Distance Matrix")
#Distances and time matrix
# 1/Method automatic generated data
distance_matrix = pairwise_distances(X=X)*111*1000 #In meters
distance_matrix = numpy.around(distance_matrix,0)
time_matrix = distance_matrix/ 0.013/1000 #50 km/h mean speed (in seconds)
time_matrix = numpy.around(time_matrix,0)

# 2/Method data from router (read from file)
# with open("data/temp_2.json") as input:
#     data = json.load(input)
#     distance_matrix = numpy.array(data["matrices"][0]["distance"], dtype = numpy.float64)
#     time_matrix = numpy.array(data["matrices"][0]["time"], dtype = numpy.float64)

distance_matrix = numpy.array([distance_matrix])
time_matrix = numpy.array([time_matrix])

sticky_vehicles = {1 : numpy.array([1], dtype=numpy.int32)}

paths = process_initial_solution(NUM_VEHICLE, time_matrix[0], STORE_INDEXES, sticky_vehicles)

#generates random time windows within a range to model multiple peaks of traffic
tw = get_mixture_truncated_normal(
    num_values=SIZE + 1,
    weights = [0.4, 0.6],
    means= [8, 12],
    sigmas= [1, 1],
    low = 8,
    upp = 12
    )

tw = numpy.trunc(tw)

start_tw = numpy.array([[random.choice(range(8,12,1))*3600, 11*3600] for _ in range(SIZE+1)], dtype=float)
start_tw[0] = [0]
end_tw = start_tw + 2*3600
end_tw[0] = [1000000]

start_tw[1,0] = 10*3600
end_tw[1,0] = 11*3600
tw_margin = numpy.array([[0, 0] for _ in range(SIZE+1)], dtype=float)
tw_margin[0,0] = 0
tw_margin[0,1] = 0

# import matplotlib.pyplot as plt


# Afficher l'histogramme de la distribution de mélange bordée
# plt.hist(tw, bins=20)
# plt.show()


#Cost factors
cost_distance_multiplier = numpy.array([0.3 for _ in range(NUM_VEHICLE)])
cost_time_multiplier = numpy.array([15.0 for _ in range(NUM_VEHICLE)])
vehicle_fixed_cost = numpy.array([500 for _ in range(NUM_VEHICLE)])
vehicle_start_time_window = numpy.array([6*3600 for _ in range(NUM_VEHICLE)], dtype=numpy.float64)
vehicle_end_time_window = numpy.array([13*3600 for _ in range(NUM_VEHICLE)], dtype=numpy.float64)
vehicle_capacity = numpy.array([MAX_CAPACITY for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_max_distance = numpy.array([300000 for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_fixed_costs = numpy.array([500 for _ in range(NUM_VEHICLE)], dtype= numpy.float64)
vehicle_overload_multiplier = numpy.array([[0] for _ in range(NUM_VEHICLE)], dtype=numpy.float64)

previous_vehicle = numpy.array([ -1 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)
vehicle_start_index = numpy.array([0 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)
vehicle_end_index = numpy.array([0 for _ in range(NUM_VEHICLE)], dtype= numpy.int32)

predecessor_successor_gap = numpy.array([[1,2,3000,-1], [2,3,7200, 10000],[4,5,3600, 8000]], dtype= numpy.int32)
is_break = numpy.zeros(SIZE+1, dtype= numpy.int32)
is_break[1] = 1
durations[1] = 3600


solution = cvrptw.CVRPTW(
    paths = paths, 
    distance_matrix = distance_matrix, 
    time_matrix = time_matrix,
    start_time_windows = start_tw, 
    end_time_windows = end_tw, 
    time_windows_margin = tw_margin,
    durations = durations,
    setup_durations = setup_durations,
    services_volumes = services_volume,
    cost_distance_multiplier = cost_distance_multiplier, 
    cost_time_multiplier = cost_time_multiplier,
    vehicle_capacities = vehicle_capacity,
    previous_vehicle = previous_vehicle,
    vehicle_max_distance = vehicle_max_distance,
    vehicle_fixed_costs = vehicle_fixed_costs,
    vehicle_overload_multiplier = vehicle_overload_multiplier,
    vehicle_start_time_window = vehicle_start_time_window,
    vehicle_end_time_window = vehicle_end_time_window,
    vehicle_start_index = vehicle_start_index,
    vehicle_end_index = vehicle_end_index,
    vehicle_start_mode = numpy.array([1 for _ in range(NUM_VEHICLE)], dtype=numpy.int32),
    predecessor_successor_gap = predecessor_successor_gap,
    is_break = is_break,
    sticky_vehicles = sticky_vehicles,
    num_units = 1)

# cProfile.run('solver.optimize(solution= solution,max_execution_time= 1*60,problem = None,groups_max_capacity=MAX_CAPACITY)')

solver.optimize(
    solution = solution,
    max_execution_time = 60*1,
    problem = None,
    groups_max_capacity = MAX_CAPACITY[0],
    grouping=False)


log.info("ENDING INITIALIZATION JOB")