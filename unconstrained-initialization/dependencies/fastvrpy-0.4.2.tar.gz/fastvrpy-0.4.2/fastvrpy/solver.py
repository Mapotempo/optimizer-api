import numpy
import time
from fastvrpy.core.cleaning.clean_vehicles import clean_vehicles
from fastvrpy.core.cleaning.clean_services import clean_services_tw, clean_services_sticky, clean_services_breaks
from fastvrpy.core import algorithm
from fastvrpy.parameters import moves_parameters

from fastvrpy.utils import *

import logging as log
log = log.getLogger("solver")


def calc_ls_iteration_number(solution):
    num_iteration = int(200000 * pow(numpy.mean(solution.vehicle_num_services), 1.25))
    if num_iteration < 1000000:
        num_iteration = 1000000
    elif num_iteration > 30000000:
        num_iteration = 30000000

    return num_iteration

def optimize(solution, max_execution_time, problem, groups_max_capacity = 20, grouping = True):
    global moves_parameters



    log.info(f"START optimization")

    tic = time.time()
    log.info(f"Initial solution cost : {solution.total_cost}")

    #Adapt moves_parameters if needed
    if numpy.all(numpy.array(solution.previous_vehicle) == -1):
        log.info("Don't need VECTOR_RELOCATE move, no vehicle dependance or multitour detected")
        moves_parameters["VECTOR_RELOCATE"]["Called"] = False

    # Group point to simplify the solution
    if grouping:
        if problem is None:
            groups = solution_bundle(solution, groups_max_capacity)
        else:
            groups_max_capacity = max_group_size(list(solution.vehicle_capacities), list(solution.services_volumes), solution.num_units)
            groups = solution_grouping(solution, 10, problem)

        if max((len(group) for group in groups)) > 3:

            log.info("Create Reduced Solution")

            reduced_solution = cluster_bundle(solution, groups)

            #cProfile.run('algorithm.local_search(solution, NUM_ITER)')
            #algorithm.local_search(solution, NUM_ITER)
            log.info("Optimize Reduced Solution")


            tac = time.time()
            elapsed_time = tac - tic

            ils_time = (max_execution_time - elapsed_time)/3
            if ils_time < 1 :
                ils_time = 1

            #Arbritrary function to decide number of iteration...
            ls_max_iterations = calc_ls_iteration_number(reduced_solution)

            log.info(f"Reduced solution ILS execution time is set to {ils_time} seconds ({ls_max_iterations} step by iteration)")

            algorithm.ils(
                solution = reduced_solution,
                max_time = ils_time,
                max_iteration = 1000000000,
                ls_max_iterations = ls_max_iterations,
                moves_parameters = moves_parameters,
                perturbation_rate = 5)

            print_kpis(reduced_solution)

            unbundle_paths = solution_unbundle(reduced_solution, groups)
            solution.paths = unbundle_paths
            solution.init_calculated_attributes()

        else:
            log.info("No solution grouping needed")

    log.info("Optimize Final Solution")

    tac = time.time()
    elapsed_time = tac - tic

    ils_time = (max_execution_time - elapsed_time)/1.5
    if ils_time < 1 :
        ils_time = 1

    #Arbritrary function to decide number of iteration...
    ls_max_iterations = calc_ls_iteration_number(solution)

    log.info(f"Finale solution ILS execution time is set to {ils_time} seconds ({ls_max_iterations} step by iteration)")

    algorithm.ils(
        solution = solution,
        max_time = ils_time,
        max_iteration = 1000000000,
        ls_max_iterations = ls_max_iterations,
        moves_parameters = moves_parameters,
        perturbation_rate = 5)


    print_kpis(solution)

    log.info("Start cleaning services")
    log.info("-- TW Cleaning")
    clean_services_tw(solution)
    log.info("-- Sticky Cleaning")
    clean_services_sticky(solution)
    log.info("-- Breaks Cleaning")
    clean_services_breaks(solution)
    log.info("End cleaning services")

    log.info("Start cleaning vehicles")
    clean_vehicles(solution)
    log.info("End cleaning vehicles")


    moves_parameters["ASSIGN"]["Called"] = True
    moves_parameters["UNASSIGN_SWAP"]["Called"] = True

    tac = time.time()
    elapsed_time = tac - tic

    ils_time = (max_execution_time - elapsed_time)
    if ils_time < 1 :
        ils_time = 1


    log.info(f"Unassign optimization ILS execution time is set to {ils_time} seconds ({ls_max_iterations} step by iteration)")

    algorithm.ils(
    solution = solution,
    max_time = ils_time,
    max_iteration = 1000000000,
    ls_max_iterations = ls_max_iterations,
    moves_parameters = moves_parameters,
    perturbation_rate = 5)


    algorithm.calc_latest_start(solution)

    print_kpis(solution)

    log.info(solution)
    log.info(f"END optimization")
