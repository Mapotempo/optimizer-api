import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW


paths = np.array([[1,2,3,4,5]], dtype=np.int32)
distance_matrix = np.array([[[0,1,1,1,1,1],
                            [1,0,1,1,1,1],
                            [1,1,0,1,1,1],
                            [1,1,1,0,1,1],
                            [1,1,1,1,0,1],
                            [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1,2,3],
                        [10,4,1,0,10,20],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)



def test_max_late_no_late():

    start_tw = np.array([[0],[0],[0],[0],[0],[10]], dtype=float)
    end_tw = np.array([[-1],[-1],[-1],[-1],[-1],[20]], dtype=float)


    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,3,4,14,19,0]]), solution.starts)
    assert np.array_equal(np.array([0]), np.array(solution.vehicle_max_late))

def test_max_late_one_late():

    start_tw = np.array([[0],[0],[0],[0],[0],[10]], dtype=float)
    end_tw = np.array([[-1],[-1],[-1],[-1],[-1],[15]], dtype=float)


    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,3,4,14,19,0]]), solution.starts)
    assert np.array_equal(np.array([4]), np.array(solution.vehicle_max_late))



@pytest.mark.parametrize("time4, expected", [
    (13, 4),
    (12, 4),
    (10, 4),
    (9, 5)])
def test_max_late_2_lates(time4, expected):

    start_tw = np.array([[0],[0],[0],[0],[0],[10]], dtype=float)
    end_tw = np.array([[-1],[-1],[-1],[-1],[time4],[15]], dtype=float)


    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([[0,1,3,4,14,19,0]]), solution.starts)
    assert np.array_equal(np.array([expected]), np.array(solution.vehicle_max_late))


def test_max_late_with_multitw():

    start_tw = np.array([[0, -1],[1, -1],[-1, -1],[-1, -1],[-1, -1],[5, 13]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[-1, -1],[-1, -1],[10, 15]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([4]), np.array(solution.vehicle_max_late))


def test_max_late_with_multitw_2_lates():

    start_tw = np.array([[0, -1],[1, -1],[-1, -1],[-1, -1],[0, 6],[5, 13]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[-1, -1],[-1, -1],[5, 8],[10, 15]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )

    assert np.array_equal(np.array([6]), np.array(solution.vehicle_max_late))

def test_max_late_with_multitw_2_lates_2_vehicles():

    paths = np.array([[1,2,3,-1,-1],[4,5,-1,-1,-1]], dtype=np.int32)


    start_tw = np.array([[0, -1],[1, -1],[0, -1],[1, -1],[8, -1],[9, -1]], dtype=float)
    end_tw = np.array([[-1, -1],[-1, -1],[1, -1],[2, -1],[10, -1],[12, -1]], dtype=float)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        start_time_windows = start_tw,
        end_time_windows = end_tw,
        num_units = 0,
        )
    assert np.array_equal(np.array([2,8]), np.array(solution.vehicle_max_late))
