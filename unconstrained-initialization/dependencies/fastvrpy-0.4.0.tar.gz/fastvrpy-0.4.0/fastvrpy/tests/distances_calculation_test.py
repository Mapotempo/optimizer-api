import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW


def test_distance():

    paths = np.array([[1,2,3,]], dtype=np.int32)
    distance_matrix = np.array([[[0,1,1,1,],
                                [1,0,1,1,],
                                [1,1,0,1,],
                                [1,1,1,0,],]], dtype=np.float64)

    solution = CVRPTW(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = distance_matrix, 
        num_units = 0,
        )
        
    assert np.array_equal(np.array([4]), solution.distances)


def test_distance2():

    paths = np.array([[1,2,3,]], dtype=np.int32)
    distance_matrix = np.array([[[0,1,1,1,],
                                [1,0,2,1,],
                                [1,1,0,3,],
                                [4,1,1,0,],]], dtype=np.float64)

    solution = CVRPTW(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = distance_matrix, 
        num_units = 0,
        )
        
    assert np.array_equal(np.array([10]), solution.distances)


def test_distance_2_vehicles():

    paths = np.array([[1,2,3,], [3,2,-1]], dtype=np.int32)
    distance_matrix = np.array([[[0,1,1,1,],
                                [1,0,2,1,],
                                [3,1,0,3,],
                                [4,1,2,0,],]], dtype=np.float64)

    solution = CVRPTW(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = distance_matrix, 
        num_units = 0,
        )
        
    assert np.array_equal(np.array([10, 6]), solution.distances)


@pytest.fixture(params=[
    [[1,2,3,4,5]],
    [[1,2,3,-1,-1], [4,5,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,-1,-1,-1], [3,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1], [4,5,3,-1,-1], [-1,-1,-1,-1,-1]],
    ])
def path_fixture(request):
    return request.param

def test_distances_with_fixture(path_fixture):
    distance_matrix = np.array([[[0,1,5,10,15,20],
                                [1,0,2,4,6,8],
                                [5,2,0,1,2,3],
                                [10,4,1,0,10,20],
                                [15,6,2,10,0,5],
                                [20,8,3,20,5,0],]], dtype=np.float64)

    distances = []
    for path in path_fixture:
        distance = 0
        current = 0
        for next in path:
            if next == -1:
                break
            distance += distance_matrix[0,current, next]
            current = next
        distance += distance_matrix[0,current, 0]
        distances.append(distance)

    paths = np.array(path_fixture, dtype=np.int32)

    solution = CVRPTW(
        paths = paths, 
        distance_matrix = distance_matrix, 
        time_matrix = distance_matrix, 
        num_units = 0,
        )
    
    for i in range(solution.num_vehicles):
        assert distances[i] == solution.distances[i]
