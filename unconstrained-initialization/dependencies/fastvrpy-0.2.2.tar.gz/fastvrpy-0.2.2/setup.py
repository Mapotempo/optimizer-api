# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fastvrpy',
 'fastvrpy.core',
 'fastvrpy.core.cleaning',
 'fastvrpy.core.solutions',
 'fastvrpy.core.utils']

package_data = \
{'': ['*'], 'fastvrpy.core': ['moves/*']}

install_requires = \
['Cython>=0.29.32,<0.30.0',
 'matplotlib>=3.6.2,<4.0.0',
 'numpy>=1.23.4,<2.0.0',
 'plotly>=5.11.0,<6.0.0',
 'psutil>=5.9.4,<6.0.0',
 'scikit-learn>=1.1.3,<2.0.0',
 'scipy>=1.9.3,<2.0.0']

setup_kwargs = {
    'name': 'fastvrpy',
    'version': '0.2.2',
    'description': '',
    'long_description': 'To install the package :\n\n- Install poetry\n    pip install poetry\n\n- Open the virtual env shell\n    python -m poetry shell\n\n- In the virtual env shell, Install all packages\n    poetry install\n\n\nTo build the package:\n\n- Add version tag on git (Major.Minor.Patch)\n\n- Update version on poetry\n    poetry version $(git describe --tags --abbrev=0)\n\n- Build package\n    poetry build\n\n- Amend last commit to integrate the new version\n\n',
    'author': 'Guillaume Maran',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
