import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW
from fastvrpy.core import algorithm




distance_matrix = np.array([[[0,1,2,3,4,5],
                            [6,0,7,8,9,10],
                            [11,12,0,1000,14,15],
                            [16,17,18,0,0,0],
                            [19,20,21,22,0,23],
                            [2,2,3,24,25,0],]], dtype=np.float64)

time_matrix = np.array([[[0,1,5,10,15,20],
                        [1,0,2,4,6,8],
                        [5,2,0,1000,2,3],
                        [10,4,1,0,0,0],
                        [15,6,2,10,0,5],
                        [20,8,3,20,5,0],]], dtype=np.float64)

@pytest.fixture(params=[
    [[-1,-1,-1,-1,-1]],
    [[1,2,3,4,5, -1]],
    [[1,2,3,4,5, -1], [-1,-1,-1,-1,-1,-1]],
    [[1,2,3,-1,-1,-1], [4,5,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1,-1], [4,5,-1,-1,-1,-1], [3,-1,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1, -1], [4,5,3,-1,-1,-1], [-1,-1,-1,-1,-1,-1]],
    [[1,2,-1,-1,-1,-1], [4,5,3,-1,-1,-1], [-1,-1,-1,-1,-1,-1], [-1,-1,-1,-1,-1,-1]],
    ])
def path_fixture(request):
    return request.param

@pytest.fixture(params=[1, 2, 3, 4, 5, 6, 10])#
def k_fixture(request):
    return request.param

@pytest.fixture(params=[True, False])
def previous_fixture(request):
    return request.param


def test_ils_no_cosnstraints(path_fixture, k_fixture):
    """
    Here we basically check if we optimize something
    """
    moves_parameters = {
            "OPT2" : {
                "Called" : True
            },
            "SWAP" : {
                "Called" : True,
                "KMax" : k_fixture,
            },
            "RELOCATE" : {
                "Called" : True,
                "KMax" : k_fixture,
            },
            "INTER_VECTOR_SWAP" : {
                "Called" : True,
                "KMax" : k_fixture,
            },
            "INTER_VECTOR_RELOCATE" : {
                "Called" : True,
                "KMax" : k_fixture,
            },
            "VECTOR_RELOCATE" : {
                "Called" : True,
                "KMax" : k_fixture,
            },
            "ASSIGN" : {
                "Called" : False,
            },
            "UNASSIGN_SWAP" : {
                "Called" : False,
            },
        }

    paths = np.array(path_fixture, dtype=np.int32)

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0)

    # print(np.array(solution.paths))
    # print("matrix indicies", np.array(solution.service_matrix_index))
    # print("num services :", np.array(solution.num_services))
    # print(np.array(solution.services_volumes))
    # print(np.array(solution.durations))
    # print(np.array(solution.setup_durations))
    # print(np.array(solution.start_time_windows))
    # print(np.array(solution.end_time_windows))
    # print("sticky services : ", np.array(solution.sticky_vehicles))

    cost = solution.total_cost

    algorithm.ils(
        solution = solution,
        max_time = 1,
        max_iteration = 100000,
        ls_max_iterations = 500,
        moves_parameters = moves_parameters,
        perturbation_rate = 5)

    if cost > 0:
        assert solution.total_cost < cost
    else:
        assert solution.total_cost == 0
