import pytest
import numpy as np
from fastvrpy.core.solutions.cvrptw import CVRPTW

paths = np.array([[1,2,3,4,5]], dtype=np.int32)

distance_matrix = np.array([[[0,1,1,1,1,1],
                             [1,0,1,1,1,1],
                             [1,1,0,1,1,1],
                             [1,1,1,0,1,1],
                             [1,1,1,1,0,1],
                             [1,1,1,1,1,0],]], dtype=np.float64)

time_matrix     = np.array([[[0,1,5,10,15,20],
                             [1,0,2,4,6,8],
                             [5,2,0,1,2,3],
                             [10,4,1,0,10,20],
                             [15,6,2,10,0,5],
                             [20,8,3,20,5,0],]], dtype=np.float64)

def test_no_quantities():

    solution = CVRPTW(
        paths = paths,
        distance_matrix = distance_matrix,
        time_matrix = time_matrix,
        num_units = 0,
        )

    assert np.array_equal(np.array([[]]), np.array(solution.vehicle_occupancies))

def test_one_units_but_equal_to_zero():
    services_volumes = np.array([[0] for i in range(6)], dtype=np.float64)
    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        services_volumes    = services_volumes,
        num_units           = 1
        )

    assert np.array_equal(np.array([[0]]), np.array(solution.vehicle_occupancies))

def test_one_units():
    services_volumes = np.array([[0],[1],[1],[1],[1],[1]], dtype=np.float64)
    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        services_volumes    = services_volumes,
        num_units           = 1
        )

    assert np.array_equal(np.array([[5]]), np.array(solution.vehicle_occupancies))

def test_two_units():
    services_volumes = np.array([[0,0],[1,2],[1,2],[1,2],[1,2],[1,2]], dtype=np.float64)
    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        services_volumes    = services_volumes,
        num_units           = 2
        )

    assert np.array_equal(np.array([[5,10]]), np.array(solution.vehicle_occupancies))

def test_one_units_two_vehicles():
    paths = np.array([[1,2,-1,-1,-1],[3,4,5,-1,-1]], dtype=np.int32)
    services_volumes = np.array([[0],[1],[1],[1],[1],[1]], dtype=np.float64)
    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        services_volumes    = services_volumes,
        num_units           = 1
        )

    assert np.array_equal(np.array([[2],[3]]), np.array(solution.vehicle_occupancies))

def test_two_units_two_vehicles():
    paths = np.array([[1,2,-1,-1,-1],[3,4,5,-1,-1]], dtype=np.int32)
    services_volumes = np.array([[0,0],[1,2],[1,2],[1,2],[1,2],[1,2]], dtype=np.float64)
    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        services_volumes    = services_volumes,
        num_units           = 2
        )
    assert np.array_equal(np.array([[2,4],[3,6]]), np.array(solution.vehicle_occupancies))

def test_two_units_two_vehicles():
    paths = np.array([[1,2,-1,-1,-1],[3,4,5,-1,-1]], dtype=np.int32)
    services_volumes = np.array([[0,0],[1,2],[1,2],[1,2],[1,2],[1,2]], dtype=np.float64)
    solution = CVRPTW(
        paths               = paths,
        distance_matrix     = distance_matrix,
        time_matrix         = time_matrix,
        services_volumes    = services_volumes,
        num_units           = 2
        )
    assert np.array_equal(np.array([[2,4],[3,6]]), np.array(solution.vehicle_occupancies))

def test_two_units_two_vehicles():
    with pytest.raises(ValueError):
        services_volumes = np.array([[0],[1,2],[1,2],[1,2],[1,2],[1,2]], dtype=np.float64)
