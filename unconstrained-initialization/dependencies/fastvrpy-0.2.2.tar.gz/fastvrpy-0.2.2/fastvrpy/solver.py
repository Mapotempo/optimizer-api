import numpy
import time
import schema
from fastvrpy.core.cleaning.clean_vehicles import clean_vehicles
from fastvrpy.core.cleaning.clean_services import clean_services
from fastvrpy.core import algorithm
from fastvrpy.parameters import moves_parameters

from fastvrpy.utils import *

import logging as log
log = log.getLogger("solver")

def optimize(solution, max_execution_time, problem, groups_max_capacity = 20):
    global moves_parameters

    total_services = numpy.sum(solution.vehicle_num_services)


    log.info(f"START optimization")

    tic = time.time()
    log.info(f"Initial solution cost : {solution.total_cost}")

    #Adapt moves_parameters if needed
    if numpy.all(numpy.array(solution.previous_vehicle) == -1):
        log.info("Don't need VECTOR_RELOCATE move, no vehicle dependance or multitour detected")
        moves_parameters["VECTOR_RELOCATE"]["Called"] = False

    # Group point to simplify the solution
    if problem is None:
        groups = solution_bundle(solution, groups_max_capacity)
    else:
        groups = solution_grouping(solution, groups_max_capacity, problem)

    if max((len(group) for group in groups)) > 3:

        log.info("Create Reduced Solution")

        reduced_solution = cluster_bundle(solution, groups)

        #cProfile.run('algorithm.local_search(solution, NUM_ITER)')
        #algorithm.local_search(solution, NUM_ITER)
        log.info("Optimize Reduced Solution")


        tac = time.time()
        elapsed_time = tac - tic

        ils_time = (max_execution_time - elapsed_time)/1.5
        if ils_time < 5 :
            ils_time = 5

        #Arbritrary function to decide number of iteration...
        ls_max_iterations = int(200000 * pow(numpy.mean(reduced_solution.vehicle_num_services), 1.5))
        if ls_max_iterations < 1000000:
            ls_max_iterations = 1000000
        elif ls_max_iterations > 100000000:
            ls_max_iterations = 100000000
        log.info(f"Reduced solution ILS execution time is set to {ils_time} seconds ({ls_max_iterations} step by iteration)")

        algorithm.ils(
            solution = reduced_solution,
            max_time = ils_time,
            max_iteration = 1000000000,
            ls_max_iterations = ls_max_iterations,
            moves_parameters = moves_parameters,
            perturbation_rate = 5)


        unbundle_paths = solution_unbundle(reduced_solution, groups)
        solution.paths = unbundle_paths
        solution.init_calculated_attributes()
        solution.init_max_cost_attributes()

        #Evaluate the initial solution (all the possible paths must be evaluated)
        solution.evaluate(numpy.array(list(range(solution.num_vehicles)), dtype = numpy.int32))
    else:
        log.info("No solution grouping needed")

    log.info("Optimize Final Solution")

    tac = time.time()
    elapsed_time = tac - tic

    ils_time = (max_execution_time - elapsed_time)
    if ils_time < 5 :
        ils_time = 5

    #Arbritrary function to decide number of iteration...
    ls_max_iterations = int(200000 * pow(numpy.mean(solution.vehicle_num_services), 1.5))
    if ls_max_iterations < 1000000:
        ls_max_iterations = 1000000
    elif ls_max_iterations > 100000000:
        ls_max_iterations = 100000000

    log.info(f"Finale solution ILS execution time is set to {ils_time} seconds ({ls_max_iterations} step by iteration)")

    algorithm.ils(
        solution = solution,
        max_time = ils_time,
        max_iteration = 1000000000,
        ls_max_iterations = ls_max_iterations,
        moves_parameters = moves_parameters,
        perturbation_rate = 5)

    print_kpis(solution)

    log.info("Start cleaning services")
    clean_services(solution)
    log.info("End cleaning services")

    log.info("Start cleaning vehicles")
    clean_vehicles(solution)
    log.info("End cleaning vehicles")

    log.info(f"Unassigned : {len(solution.unassigned)} ( {int(len(solution.unassigned)/total_services * 100)}% )")
    log.info(solution)
    log.info(f"END optimization")
