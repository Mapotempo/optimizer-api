import os

# See if Cython is installed
try:
    from Cython.Build import cythonize
# Do nothing if Cython is not available
except ImportError:
    # Got to provide this function. Otherwise, poetry will fail
    def build(setup_kwargs):
        pass
# Cython is installed. Compile
else:
    from setuptools import Extension
    from setuptools.dist import Distribution
    from distutils.command.build_ext import build_ext

    import numpy

    # This function will be executed in setup.py:
    def build(setup_kwargs):
        # The file you want to compile
        extensions = [
            Extension("fastvrpy.core.algorithm", ["fastvrpy/core/algorithm.pyx"], output_dir="build"),
            Extension("fastvrpy.core.solutions.cvrptw", ["fastvrpy/core/solutions/cvrptw.pyx"], output_dir="build"),
            Extension("fastvrpy.core.solutions.solution", ["fastvrpy/core/solutions/solution.pyx"], output_dir="build"),
            Extension("fastvrpy.core.cleaning.clean_vehicles", ["fastvrpy/core/cleaning/clean_vehicles.pyx"], output_dir="build"),
            Extension("fastvrpy.core.cleaning.clean_services", ["fastvrpy/core/cleaning/clean_services.pyx"], output_dir="build"),
            Extension("fastvrpy.core.utils.operators", ["fastvrpy/core/utils/operators.pyx"], output_dir="build"),
            Extension("fastvrpy.core.utils.evaluation_utils", ["fastvrpy/core/utils/evaluation_utils.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.move", ["fastvrpy/core/moves/move.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.opt2", ["fastvrpy/core/moves/opt2.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.swap", ["fastvrpy/core/moves/swap.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.relocate", ["fastvrpy/core/moves/relocate.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.inter_swap", ["fastvrpy/core/moves/inter_swap.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.inter_relocate", ["fastvrpy/core/moves/inter_relocate.pyx"], output_dir="build"),
            Extension("fastvrpy.core.moves.vector_relocate", ["fastvrpy/core/moves/vector_relocate.pyx"], output_dir="build"),

        ]

        # gcc arguments hack: enable optimizations
        os.environ['CFLAGS'] = '-O3'

        # Build
        setup_kwargs.update({
            'ext_modules': cythonize(
                extensions,
                language_level=3,
                annotate=True,
                gdb_debug=True,
                compiler_directives={'linetrace': True},
            ),
            'cmdclass': {'build_ext': build_ext},
            'include_dirs': [numpy.get_include()],
        })
